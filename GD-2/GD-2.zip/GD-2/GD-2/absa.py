# Aspect-based sentiment analysis logic (placeholder)

"""
Lightweight hybrid ABSA (rule-based) with Hinglish support and conjunction handling.
- Aspect extraction: keyword matching from aspects.json.
- Hinglish handling: basic mapping of common Hindi words to English (transliteration mapping).
- Conjunction handling: split on conjunctions like "but", "par", "lekin", "magar", "aur", "and".
- Sentiment: lexicon-based scoring using small positive/negative lists (includes Hinglish words).
- Outputs aspect -> {sentiment, evidence_clause} and automated response suggestion.
This is designed to run offline without heavy model downloads.
"""

import re
import json
from pathlib import Path

HERE = Path(__file__).parent

# Load aspects and lexicons
with open(HERE / "aspects.json", "r", encoding="utf-8") as f:
    ASPECT_KEYWORDS = json.load(f)

with open(HERE / "pos_words.json", "r", encoding="utf-8") as f:
    POS_WORDS = set(json.load(f))

with open(HERE / "neg_words.json", "r", encoding="utf-8") as f:
    NEG_WORDS = set(json.load(f))

# Simple Hinglish normalization mapping (common words)
HINGLISH_MAP = {
    "accha":"good","acha":"good","badhiya":"good","best":"best","bura":"bad","kharaab":"bad","acha tha":"good",
    "service":"service","seva":"service","khana":"food","food":"food","tasty":"food","swachhta":"cleanliness",
    "safai":"cleanliness","price":"price","daam":"price","keemat":"price","delivery":"delivery","der":"delay","late":"delay",
    "taste":"food","ambience":"ambience","mazaa":"good","acha":"good","mehenga":"expensive","sasta":"cheap"
}

# Conjunctions to split clauses
CONJ_PATTERN = re.compile(r'\b(but|however|although|par|lekin|magar|but,|and|aur)\b', flags=re.IGNORECASE)

def normalize_text(text):
    t = text.lower()
    # replace punctuation with spaces
    t = re.sub(r'[^\w\s]', ' ', t)
    # replace multiple spaces
    t = re.sub(r'\s+', ' ', t).strip()
    # map hinglish words
    for k,v in HINGLISH_MAP.items():
        t = re.sub(r'\b' + re.escape(k) + r'\b', v, t)
    return t

def split_clauses(text):
    """
    Split on conjunctions but keep conjunction word to understand contrast.
    Returns list of clauses.
    """
    parts = CONJ_PATTERN.split(text)
    # parts like [before, conj, after, conj, after...]
    clauses = []
    i = 0
    while i < len(parts):
        if i+1 < len(parts) and re.match(CONJ_PATTERN, parts[i+1]):
            clause = (parts[i].strip(), parts[i+1].strip())
            clauses.append(clause)
            i += 2
        else:
            clauses.append((parts[i].strip(), ""))
            i += 1
    return clauses

def extract_aspects_from_clause(clause):
    found = set()
    for aspect, keywords in ASPECT_KEYWORDS.items():
        for kw in keywords:
            if re.search(r'\b' + re.escape(kw) + r'\b', clause):
                found.add(aspect)
                break
    return list(found)

def score_sentiment(clause):
    """
    Simple lexicon scoring: +1 per positive word, -1 per negative word.
    Return 'positive','negative','neutral' and score.
    """
    words = clause.split()
    score = 0
    for w in words:
        if w in POS_WORDS:
            score += 1
        if w in NEG_WORDS:
            score -= 1
    if score > 0:
        return "positive", score
    if score < 0:
        return "negative", score
    return "neutral", score

def analyze_review(review_text):
    """
    Returns a dict:
    {
      "clauses": [
         {"text": ..., "conj": "...", "aspects": [...], "sentiment":"", "score":int}
      ],
      "aspect_summary": {aspect: {"sentiment": aggregated, "evidence": [clauses...]}}
    }
    """
    norm = normalize_text(review_text)
    raw_clauses = split_clauses(norm)
    clauses_info = []
    # analyze each clause
    for txt, conj in raw_clauses:
        txt = txt.strip()
        if not txt:
            continue
        aspects = extract_aspects_from_clause(txt)
        sentiment, score = score_sentiment(txt)
        clauses_info.append({"text": txt, "conj": conj, "aspects": aspects, "sentiment": sentiment, "score": score})
    # Aggregate per aspect
    aspect_summary = {}
    for c in clauses_info:
        target_aspects = c["aspects"] if c["aspects"] else ["general"]
        for asp in target_aspects:
            if asp not in aspect_summary:
                aspect_summary[asp] = {"scores": [], "evidence": []}
            aspect_summary[asp]["scores"].append(c["score"])
            aspect_summary[asp]["evidence"].append(c["text"])
    # Reduce to sentiment label
    for asp, data in aspect_summary.items():
        total = sum(data["scores"])
        if total > 0:
            label = "positive"
        elif total < 0:
            label = "negative"
        else:
            label = "neutral"
        aspect_summary[asp]["sentiment"] = label
        aspect_summary[asp]["total_score"] = total
    # Build automated responses
    responses = {}
    for asp, data in aspect_summary.items():
        if asp == "general":
            keyname = "Overall"
        else:
            keyname = asp.capitalize()
        if data["sentiment"] == "positive":
            resp = f"Thanks for your positive feedback about {keyname}! We're happy you liked it. We'd love if you could share more details or recommend us to friends."
        elif data["sentiment"] == "negative":
            resp = f"Sorry to hear about your experience with {keyname}. We apologise and would like to make it right. Could you share more details (time, order id) so we can investigate and improve?"
        else:
            resp = f"Thanks for the note on {keyname}. Could you tell us a bit more about what you liked or didn't like so we can improve?"
        responses[keyname] = resp
    return {"clauses": clauses_info, "aspect_summary": aspect_summary, "responses": responses}
