# Flask app with college selection & filters (placeholder)
import re
import pandas as pd
from collections import Counter
from flask import Flask, render_template, request, send_file, redirect, url_for
import mysql.connector
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix
import json
import io
import csv

app = Flask(__name__)

# ==============================
# Database Connection
# ==============================
db = mysql.connector.connect(
    host="localhost",
    user="root",         # change if needed
    password="123456",   # change if needed
    database="reviews_db"
)
cursor = db.cursor(dictionary=True)

# ==============================
# Helpers (Database)
# ==============================
def load_reviews():
    cursor.execute("SELECT * FROM reviews")
    return cursor.fetchall()

def save_review(review, sentence, aspect, sentiment, automated_response, status, true_aspect, true_sentiment, college_name):
    cursor.execute(
        """
        INSERT INTO reviews (review, sentence, aspect, sentiment, automated_response, status, true_aspect, true_sentiment, college_name) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (review, sentence, aspect, sentiment, automated_response, status, true_aspect, true_sentiment, college_name)
    )
    db.commit()

# ==============================
# Load colleges JSON (sample)
# ==============================
try:
    with open("colleges.json", "r", encoding="utf-8") as f:
        colleges_data = json.load(f)
        COLLEGES = colleges_data.get("colleges", []) if isinstance(colleges_data, dict) else colleges_data
except Exception:
    # fallback sample list if file missing
    COLLEGES = [
        "Indian Institute of Technology Kanpur",
        "Banaras Hindu University",
        "Aligarh Muslim University",
        "Dr. A.P.J. Abdul Kalam Technical University",
        "Harcourt Butler Technical University (HBTU) Kanpur",
        "Motilal Nehru National Institute of Technology",
        "Sam Higginbottom University of Agriculture, Technology and Sciences",
    ]

# ==============================
# NLP resources
# ==============================
conjunctions = [
    'and','or','but','so','because','although','though','however','yet','for','nor',
    'either','neither','as','since','while','whereas','aur','ya','lekin','to','kyunki',
    'par','magar','tab','jabki','phir bhi'
]

aspects_keywords = {
    'college': [
        'college','university','campus','institute','college life',
        'vidyalaya','institutions','reputation','ranking'
    ],
    'placement': [
        'placement','job','career','internship','recruitment','naukri',
        'package','companies','offer','opportunity'
    ],
    'food': [
        'food','mess','canteen','lunch','dinner','snacks','khana','khanna',
        'breakfast','subha ka nasta','raat ka khana','meal','thali'
    ],
    'faculty': [
        'faculty','professors','teachers','lecturers','staff','adhyapak',
        'teacher','professor','lecture','guidance','hod','sir','madam'
    ],
    'infrastructure': [
        'infrastructure','building','labs','classrooms','library',
        'facilities','area','campus building','smart class','wifi'
    ],
    'hostel': [
        'hostel','rooms','accommodation','dorm','pg','roommate',
        'mess facility','warden','pg life'
    ],
    'fees': [
        'fees','tuition','charges','payment','shulk',
        'extra charges','expensive','affordable','scholarship'
    ],
    'sports': [
        'sports','games','playground','gym','athletics','khel',
        'cricket ground','basketball ground','table tennis','tt ground'
    ],
    'library': [
        'library','books','reading room','study material','digital library',
        'journals','ebooks'
    ],
    'events': [
        'events','fest','cultural','seminar','workshop','club','functions',
        'competitions','celebration'
    ]
}
positive_words = [
    'good', 'excellent', 'best', 'happy', 'amazing', 'awesome', 'brilliant',
    'wonderful', 'nice', 'achha', 'sahi', 'mast', 'badhiya', 'acha', 'supportive',
    'helpful', 'friendly', 'enjoy', 'perfect', 'experienced', 'talented',
    'impressive', 'outstanding', 'fantastic', 'cool', 'great', 'superb',
    'motivating', 'peaceful', 'satisfactory', 'decent', 'love', 'positive',
    'encouraging', 'inspiring', 'beautiful', 'enjoyable', 'nice environment',
    'bhut badiya', 'kamaal ka', 'top class', 'very good', 'highly recommend',
    'amazing experience', 'super cool', 'exceptional', 'remarkable', 'excellent service',
    'mind-blowing', 'fabulous', 'delightful', 'friendly staff', 'well maintained',
    'good vibes', 'lovely place', 'pleasant', 'awesome support', 'perfect experience',
    'best ever', 'really good', 'superb work', 'fantastic experience', 'highly satisfied',
    'very nice', 'enjoyed a lot', 'top notch', 'impeccable', 'really amazing', 'great job',
    'so good', 'very happy', 'excellent work', 'worth it', 'brilliant service'
]
negative_words = [
    'worst', 'bad', 'poor', 'unhappy', 'awful', 'terrible', 'horrible', 'boring', 'difficult','bekar','ganda'
    'average', 'problem', 'issue', 'dirty', 'unhygienic', 'useless', 'fool', 'pathetic','Worst','Bekar','Ganda'
    'bad', 'Bad', 'BAD',
    'poor', 'Poor', 'POOR',
    'worst', 'Worst', 'WORST',
    'terrible', 'Terrible', 'TERRIBLE',
    'horrible', 'Horrible', 'HORRIBLE',
    'useless', 'Useless', 'USELESS',
    'dirty', 'Dirty', 'DIRTY',
    'unhygienic', 'Unhygienic', 'UNHYGIENIC',
    'pathetic', 'Pathetic', 'PATHETIC',
    'average', 'Average', 'AVERAGE',
    'problem', 'Problem', 'PROBLEM',
    'issue', 'Issue', 'ISSUE',
    'fool', 'Fool', 'FOOL',
    'waste', 'Waste', 'WASTE',
    'disgusting', 'Disgusting', 'DISGUSTING',

    # Hinglish / Romanized Hindi
    'bekar', 'Bekar', 'BEKAR',
    'bakar', 'Bakar', 'BAKAR',
    'bura', 'Bura', 'BURA',
    'buraa', 'Buraa', 'BURAA',
    'burra', 'Burra', 'BURRA',
    'bahut bura', 'Bahut bura', 'BAHUT BURA',
    'ganda', 'Ganda', 'GANDA',
    'gandi', 'Gandi', 'GANDI',
    'gandagi', 'Gandagi', 'GANDAGI',
    'nikamma', 'Nikamma', 'NIKAMMA',
    'bakwas', 'Bakwas', 'BAKWAS',
    'bakwass', 'Bakwass', 'BAKWASS',
    'faltu', 'Faltu', 'FALTU',
    'bevajah', 'Bevajah', 'BEVAJAH',
    'bekam', 'Bekam', 'BEKAM',
    'bekar ka', 'Bekar ka', 'BEKAR KA',
    'glt', 'Glt', 'GLT',
    'galat', 'Galat', 'GALAT',
    'kharab', 'Kharab', 'KHARAB',
    'bahut kharab', 'Bahut kharab', 'BAHUT KHARAB',
    'thik nahi', 'Thik nahi', 'THIK NAHI',
    'achha nahi', 'Achha nahi', 'ACHHA NAHI',
    'acha nahi', 'Acha nahi', 'ACHA NAHI',
    'acha nhi', 'Acha nhi', 'ACHA NHI',
    'bilkul bekar', 'Bilkul bekar', 'BILKUL BEKAR',
    'bilkul kharab', 'Bilkul kharab', 'BILKUL KHARAB',
    'bilkul ganda', 'Bilkul ganda', 'BILKUL GANDA',
    'jhuth', 'Jhuth', 'JHUTH',
    'jhooth', 'Jhooth', 'JHOOTH',
    'jhut', 'Jhut', 'JHUT',
    'thoda kharab', 'Thoda kharab', 'THODA KHARAB',
    'thik thak nahi', 'Thik thak nahi', 'THIK THAK NAHI',
    'nalaayak', 'Nalaayak', 'NALAYAK',
    'nalayak', 'Nalayak', 'NALAYAK',
    'barbad', 'Barbad', 'BARBAD',
    'beimaan', 'Beimaan', 'BEIMAAN',
    'ghatiya', 'Ghatiya', 'GHATIYA',
    'ghatiyaa', 'Ghatiyaa', 'GHATIYAA',
    'ghatiyapana', 'Ghatiyapana', 'GHATIYAPANA',
    'acha nahi laga', 'Acha nahi laga', 'ACHA NAHI LAGA',
    'pasand nahi', 'Pasand nahi', 'PASAND NAHI',
    'pasand nhi', 'Pasand nhi', 'PASAND NHI',
    'bura laga', 'Bura laga', 'BURA LAGA',
    'pura fail', 'Pura fail', 'PURA FAIL',
    'kachra', 'Kachra', 'KACHRA',
    'kchra', 'Kchra', 'KCHRA',
    'kaam nahi karta', 'Kaam nahi karta', 'KAAM NAHI KARTA',
    'kaam nahi kar raha', 'Kaam nahi kar raha', 'KAAM NAHI KAR RAHA',
    'nhi pasand', 'Nhi pasand', 'NHI PASAND',
    'nhi achha', 'Nhi achha', 'NHI ACHHA',
    'nahi accha', 'Nahi accha', 'NAHI ACCHA',
    'not good', 'Not good', 'NOT GOOD',
    'not working', 'Not working', 'NOT WORKING'

    'disgusting', 'fraud', 'loot', 'time waste', 'fake', 'cheat', 'waste', 'low quality','worst'
    'arrogant', 'unfair', 'not good', 'delay', 'irresponsible', 'slow', 'disappointed', 
    'frustrating', 'confusing', 'messy', 'annoying', 'unpleasant', 'poor service', 'worst experience',
    'bad experience', 'needs improvement', 'not satisfied', 'regret', 'never again', 'substandard',
    'poor quality', 'lacking', 'not helpful', 'weak', 'failure', 'problematic', 'unorganized', 'unprofessional',
    # Review-style negative phrases
    'not recommended', 'poor experience', 'did not like', 'did not enjoy', 'waste of time', 
    'very bad', 'extremely poor', 'highly disappointing', 'unpleasant experience', 'below expectations',
    'unsatisfactory', 'problem faced', 'terribly managed', 'lousy', 'subpar', 'not worth it', 
    'service lacking', 'very dissatisfied', 'not happy', 'not impressed', 'could be better', 
    'disappointing service', 'lack of quality', 'frustrating experience', 'could improve', 'poor support',
    'negative experience', 'disorganized', 'weak service', 'inferior', 'mediocre', 'annoyed', 
    'stressful', 'unhelpful staff', 'unreliable', 'untrustworthy', 'bad behavior', 'rude', 'overpriced',
    'not satisfactory', 'shoddy', 'faulty', 'defective', 'unacceptable', 'incompetent',
    'misleading', 'poorly managed', 'overpromised', 'underwhelming', 'displeased', 'not enjoyable',
    'worst quality', 'frustrating service', 'unpleasant staff', 'time consuming', 'problematic service',
    'unsatisfying', 'not up to mark', 'lackluster', 'substandard service', 'inferior quality', 'poorly executed',
    'bad management', 'unpleasant experience', 'not happy with', 'low standard', 'disappoint', 'lacking quality',
    'unsatisfactory service', 'very poor', 'not acceptable', 'weak experience', 'terrible quality', 'regrettable',
    'failed expectation', 'unworthy', 'inefficient', 'inadequate', 'unreliable service', 'poorly handled'
]
offensive_words = [
    # Hindi / Hinglish Abuses
    'chutiya', 'chu*iya', 'ch**iya', 'harami', 'haraami', 'haraamzada',
    'gandu', 'gaand', 'gand', 'madarchod', 'madarch*od', 'madarchod',
    'bhosdike', 'bhosri', 'bosdike', 'behenchod', 'bahenchod', 'bc',
    'maderchod', 'maaderchod', 'randi', 'raand', 'rundi', 'chinal',
    'jhantu', 'jhaatu', 'jhant', 'jhantu', 'kutiya', 'kutti', 'kuttiya',
    'chut', 'chut*ya', 'chut*ia', 'chodu', 'chod', 'chodna', 'ch*d',
    'bevakoof', 'bakchod', 'bakchodi', 'chalu', 'nikamma', 'thakela',
    'chindi', 'bheek ka', 'launda', 'laundiya', 'chakka', 'hijra', 'meetha',

    # English Abuses
    'fuck', 'fucked', 'fucking', 'fucker', 'motherfucker', 'mf',
    'dick', 'cock', 'pussy', 'slut', 'whore', 'bitch', 'bastard',
    'asshole', 'arsehole', 'cunt', 'prick', 'bollocks', 'bloody',
    'crap', 'shit', 'bullshit', 'nonsense', 'loser', 'jerk', 'moron',
    'dumbass', 'retard', 'stupid', 'idiot', 'hoe',

    # Short Forms & Internet Slangs
    'mc', 'bc', 'bkl', 'bsdk', 'bhosdk', 'bsdk', 'gndu', 'r8ndi',
    'chmkl', 'chmgaad', 'chmc', 'chodu', 'madrc', 'mch', 'mfc',
    'fml', 'wtf', 'stfu', 'gtfo', 'nibba', 'nibbi',
    
    # Variations with numbers / masking
    'chutiy@', 'chut1ya', 'chvtiya', 'chu7iya', 'm@darchod', 'm@derchod',
    'b!tch', 'f@ck', 'fu*k', 'f#ck', 'phuck', 'fuxk', 'cuntz'
]




# ==============================
# Ground Truth Generator (Rules)
# ==============================
ASPECT_RULES = {
    "placement": "Placement",
    "job": "Placement",
    "career": "Placement",
    "internship": "Placement",
    "package": "Placement",
    "faculty": "Faculty",
    "teacher": "Faculty",
    "professor": "Faculty",
    "staff": "Faculty",
    "food": "Food",
    "canteen": "Food",
    "mess": "Food",
    "hostel": "Hostel",
    "room": "Hostel",
    "accommodation": "Hostel",
    "fees": "Fees",
    "scholarship": "Fees",
    "payment": "Fees",
    "library": "Library",
    "book": "Library",
    "reading": "Library",
    "sports": "Sports",
    "game": "Sports",
    "playground": "Sports",
    "event": "Events",
    "fest": "Events",
    "workshop": "Events",
    "club": "Events",
    "infrastructure": "Infrastructure",
    "building": "Infrastructure",
    "facility": "Infrastructure",
    "college": "College",
    "campus": "College",
    "university": "College"
}

def get_true_aspect(review):
    review_lower = review.lower()
    for keyword, aspect in ASPECT_RULES.items():
        if keyword in review_lower:
            return aspect
    return "General"

def get_true_sentiment(review):
    review_lower = review.lower()
    if any(w in review_lower for w in positive_words):
        return "Positive"
    elif any(w in review_lower for w in negative_words):
        return "Negative"
    else:
        return "Neutral"

# ==============================
# Analyzer
# ==============================
def generate_response(aspect, sentiment):
    responses = {
        'College': {
            'Positive': ["Glad to hear positive feedback about the college!"],
            'Negative': ["We're sorry to hear issues with the college. We'll look into it."],
            'Neutral':  ["Thank you for your neutral feedback on the college."]
        },
        'Placement': {
            'Positive': ["Great to hear about good placement experiences!"],
            'Negative': ["We're concerned to hear about placement issues. We’ll investigate."],
            'Neutral':  ["Thanks for your balanced view on placement."]
        },'Faculty': {
        'Positive': ["Happy to know the faculty is supporting students well!"],
        'Negative': ["Sorry to hear issues with faculty. We’ll try to improve teaching quality."],
        'Neutral':  ["Thank you for sharing feedback on the faculty."]
    },
    'Food': {
        'Positive': ["Glad you are satisfied with the food and mess services!"],
        'Negative': ["We’re sorry the food didn’t meet expectations. Improvements will be considered."],
        'Neutral':  ["Thank you for your feedback on the food facilities."]
    },
    'Hostel': {
        'Positive': ["Happy to hear that hostel facilities are good!"],
        'Negative': ["Sorry about the hostel issues. We’ll work on better accommodation."],
        'Neutral':  ["Thanks for your comments on hostel facilities."]
    },
    'Infrastructure': {
        'Positive': ["Great to know the infrastructure is meeting your needs!"],
        'Negative': ["Sorry to hear about infrastructure problems. We’ll try to improve facilities."],
        'Neutral':  ["Thank you for your feedback on infrastructure."]
    },
    'Fees': {
        'Positive': ["We’re glad you find the fee structure reasonable!"],
        'Negative': ["We understand fee concerns and will review them carefully."],
        'Neutral':  ["Thanks for your feedback regarding fees."]
    },
    'Sports': {
        'Positive': ["Happy to know you’re enjoying the sports facilities!"],
        'Negative': ["We’ll look into the issues with sports facilities and work to improve them."],
        'Neutral':  ["Thank you for your feedback on sports activities."]
    },
    'Library': {
        'Positive': ["Glad to hear you’re satisfied with the library and study resources!"],
        'Negative': ["Sorry to hear issues with library services. We’ll improve availability and access."],
        'Neutral':  ["Thanks for sharing feedback on the library."]
    },
    'Events': {
        'Positive': ["Great to know you enjoyed the events and activities!"],
        'Negative': ["We’re sorry if events didn’t meet expectations. We’ll try to organize better ones."],
        'Neutral':  ["Thank you for sharing your thoughts on the events."]
    },
        'General': {
            'Positive': ["Thanks for your positive feedback!"],
            'Negative': ["We appreciate your honest feedback and will try to improve."],
            'Neutral':  ["Thank you for sharing your thoughts."]
        }
    }
    # ensure fallback
    aspect_key = aspect if aspect in responses else 'General'
    if sentiment not in ['Positive', 'Negative', 'Neutral']:
        sentiment = 'Neutral'
    val = responses.get(aspect_key, responses['General']).get(sentiment)
    if isinstance(val, list):
        return " ".join(val)
    return val

def analyze_text(review):
    # split by conjunctions (approximate)
    clauses = re.split(r'\b(?:' + '|'.join(conjunctions) + r')\b', review, flags=re.IGNORECASE)
    analysis_results = []
    for clause in clauses:
        clause = clause.strip()
        if not clause:
            continue

        detected_aspect = None
        for aspect, keywords in aspects_keywords.items():
            if any(keyword.lower() in clause.lower() for keyword in keywords):
                detected_aspect = aspect.capitalize()
                break

        # if no known aspect found, we'll mark 'General' for now
        detected_aspect = detected_aspect or "General"

        sentiment = 'Neutral'
        if any(word in clause.lower() for word in positive_words):
            sentiment = 'Positive'
        elif any(word in clause.lower() for word in negative_words):
            sentiment = 'Negative'

        if any(word in clause.lower() for word in offensive_words):
            sentiment = 'Negative'
            status = "Rejected"
        else:
            status = "Approved"

        automated_response = generate_response(detected_aspect, sentiment)

        # Ground truth rules (sentence-level)
        true_aspect = get_true_aspect(clause)
        true_sentiment = get_true_sentiment(clause)

        analysis_results.append({
            'full_review': review,
            'sentence': clause,
            'aspect': detected_aspect,
            'sentiment': sentiment,
            'automated_response': automated_response,
            'status': status,
            'true_aspect': true_aspect,
            'true_sentiment': true_sentiment
        })
    return analysis_results

# ==============================
# Grouping helper
# ==============================
def group_results(analysis_results):
    grouped_results = {}
    for r in analysis_results:
        review = r.get('full_review') or r.get('review') or ''
        aspect = r.get('aspect', 'General')
        if review not in grouped_results:
            grouped_results[review] = {}
        if aspect not in grouped_results[review]:
            grouped_results[review][aspect] = []
        grouped_results[review][aspect].append(r)
    return grouped_results

# ==============================
# Routes
# ==============================
@app.route("/")
def index():
    # Show index with college dropdown and optional filtering parameter
    college_filter = request.args.get("college_filter", "All")
    return render_template("index.html", colleges=COLLEGES, college_filter=college_filter)

@app.route("/analyze", methods=["POST"])
def analyze():
    review = request.form.get("review_text", "").strip()
    college_name = request.form.get("college_name", "").strip()
    if not college_name:
        return render_template("index.html", colleges=COLLEGES, error="Please select a college before submitting.")

    if not review:
        return render_template("index.html", colleges=COLLEGES, error="Please enter a review.")

    analysis_results = analyze_text(review)

    # save sentence-level rows into DB (with college)
    for r in analysis_results:
        save_review(r['full_review'], r['sentence'], r['aspect'], r['sentiment'],
                    r['automated_response'], r['status'], r['true_aspect'], r['true_sentiment'], college_name)

    grouped_results = group_results(analysis_results)
    # send grouped results and college selected
    return render_template("result.html", grouped_results=grouped_results, college_selected=college_name)

@app.route("/upload", methods=["GET", "POST"])
def upload_file():
    if request.method == "POST":
        file = request.files["file"]
        college_name = request.form.get("college_name_upload", "").strip()
        if file:
            filepath = file.filename
            if filepath.endswith(".csv"):
                df = pd.read_csv(file)
                reviews = df["review"].dropna().tolist()
            elif filepath.endswith(".xlsx"):
                df = pd.read_excel(file)
                reviews = df["review"].dropna().tolist()
            else:
                return "Unsupported file format"

            all_results = []
            for review in reviews:
                results = analyze_text(review)
                for r in results:
                    save_review(r['full_review'], r['sentence'], r['aspect'], r['sentiment'],
                                r['automated_response'], r['status'], r['true_aspect'], r['true_sentiment'], college_name)
                all_results.extend(results)

            grouped_results = group_results(all_results)
            return render_template("result.html", grouped_results=grouped_results, college_selected=college_name)
    return render_template("upload.html", colleges=COLLEGES)

@app.route("/reviews")
def reviews():
    # optional filter param
    college_filter = request.args.get("college_filter", "All")
    stored_reviews = load_reviews()
    if college_filter and college_filter != "All":
        stored_reviews = [r for r in stored_reviews if r.get("college_name") == college_filter]
    grouped_results = {}
    # stored_reviews is sentence-level rows from DB; group them
    for r in stored_reviews:
        review_text = r.get("review") or r.get("full_review") or ""
        aspect = r.get("aspect") or "General"
        if review_text not in grouped_results:
            grouped_results[review_text] = {}
        if aspect not in grouped_results[review_text]:
            grouped_results[review_text][aspect] = []
        grouped_results[review_text][aspect].append({
            'sentence': r.get("sentence"),
            'aspect': r.get("aspect"),
            'sentiment': r.get("sentiment"),
            'automated_response': r.get("automated_response"),
            'status': r.get("status"),
            'true_aspect': r.get("true_aspect"),
            'true_sentiment': r.get("true_sentiment"),
            'college_name': r.get("college_name")
        })

    return render_template("reviews.html", grouped_results=grouped_results, colleges=COLLEGES, college_filter=college_filter)

@app.route("/insights")
def insights():
    college_filter = request.args.get("college_filter", "All")
    stored_reviews = load_reviews()
    if college_filter and college_filter != "All":
        stored_reviews = [r for r in stored_reviews if r.get("college_name") == college_filter]

    sentiments = [r["sentiment"] for r in stored_reviews if "sentiment" in r]
    aspects = [r["aspect"] for r in stored_reviews if "aspect" in r]
    sentiment_counts = dict(Counter(sentiments))
    aspect_counts = dict(Counter(aspects))

    # aspect vs sentiment matrix
    aspect_sentiment_matrix = {}
    for r in stored_reviews:
        asp = r.get("aspect") or "General"
        sent = r.get("sentiment") or "Neutral"
        if asp not in aspect_sentiment_matrix:
            aspect_sentiment_matrix[asp] = {"Positive": 0, "Negative": 0, "Neutral": 0}
        aspect_sentiment_matrix[asp][sent] += 1

    return render_template("insights.html",
                           sentiment_counts=sentiment_counts,
                           aspect_counts=aspect_counts,
                           aspect_sentiment_matrix=aspect_sentiment_matrix,
                           colleges=COLLEGES,
                           college_filter=college_filter)

@app.route("/accuracy")
def accuracy():
    college_filter = request.args.get("college_filter", "All")
    stored_reviews = load_reviews()
    if college_filter and college_filter != "All":
        stored_reviews = [r for r in stored_reviews if r.get("college_name") == college_filter]

    total = 0
    correct = 0
    per_review_acc = []

    y_true_sentiments = []
    y_pred_sentiments = []
    aspect_stats = {}

    sentiment_labels = ["Positive", "Negative", "Neutral"]

    # We'll group by review id (if present) or by review text to produce per-review accuracy rows
    grouped_by_review_text = {}
    for r in stored_reviews:
        review_text = r.get("review") or r.get("full_review") or ""
        if review_text not in grouped_by_review_text:
            grouped_by_review_text[review_text] = []
        grouped_by_review_text[review_text].append(r)

    for review_text, rows in grouped_by_review_text.items():
        # compute review-level predicted aspect/sentiment by majority vote (for simplicity)
        pred_sentiments = [rr.get("sentiment") for rr in rows if rr.get("sentiment")]
        pred_aspects = [rr.get("aspect") for rr in rows if rr.get("aspect")]
        true_sentiments = [rr.get("true_sentiment") for rr in rows if rr.get("true_sentiment")]
        true_aspects = [rr.get("true_aspect") for rr in rows if rr.get("true_aspect")]
        if not true_sentiments or not true_aspects:
            continue  # skip reviews without ground truth

        # majority vote (fallback to first)
        from collections import Counter as _Counter
        pred_sent = _Counter(pred_sentiments).most_common(1)[0][0] if pred_sentiments else "Neutral"
        pred_aspect = _Counter(pred_aspects).most_common(1)[0][0] if pred_aspects else "General"
        true_sent = _Counter(true_sentiments).most_common(1)[0][0]
        true_asp = _Counter(true_aspects).most_common(1)[0][0]

        total += 1
        match = (pred_sent.lower() == true_sent.lower()) and (pred_aspect.lower() == true_asp.lower())
        if match:
            correct += 1

        per_review_acc.append({
            "review": review_text,
            "system_sentiment": pred_sent,
            "true_sentiment": true_sent,
            "system_aspect": pred_aspect,
            "true_aspect": true_asp,
            "is_correct": match,
            "sentence_level": rows
        })

        # aspect stats
        if true_asp not in aspect_stats:
            aspect_stats[true_asp] = {"correct": 0, "total": 0}
        aspect_stats[true_asp]["total"] += 1
        if match:
            aspect_stats[true_asp]["correct"] += 1

        # for classification metrics
        y_true_sentiments.append(true_sent)
        y_pred_sentiments.append(pred_sent)

    overall_accuracy = round((correct / total) * 100, 2) if total > 0 else None
    aspect_acc = {a: round((v["correct"] / v["total"]) * 100, 2) for a, v in aspect_stats.items()}

    precision = round(precision_score(y_true_sentiments, y_pred_sentiments, average="macro") * 100, 2) if y_true_sentiments else None
    recall = round(recall_score(y_true_sentiments, y_pred_sentiments, average="macro") * 100, 2) if y_true_sentiments else None
    f1 = round(f1_score(y_true_sentiments, y_pred_sentiments, average="macro") * 100, 2) if y_true_sentiments else None

    # Confusion matrix
    conf_matrix = None
    if y_true_sentiments and y_pred_sentiments:
        cm = confusion_matrix(y_true_sentiments, y_pred_sentiments, labels=sentiment_labels)
        conf_matrix = {"labels": sentiment_labels, "matrix": cm.tolist()}

    return render_template("accuracy.html",
                           overall_accuracy=overall_accuracy,
                           precision=precision,
                           recall=recall,
                           f1=f1,
                           review_checks=per_review_acc,
                           correct_count=correct,
                           wrong_count=(total - correct),
                           aspect_labels=list(aspect_acc.keys()),
                           aspect_accuracy=list(aspect_acc.values()),
                           conf_matrix=conf_matrix,
                           aspect_sentiment_matrix={},  # can populate if needed for charts
                           colleges=COLLEGES,
                           college_filter=college_filter)

@app.route("/download_csv")
def download_csv():
    cursor.execute("SELECT * FROM reviews")
    rows = cursor.fetchall()

    # Create CSV in-memory
    mem = io.StringIO()
    writer = csv.writer(mem)

    # header row
    header = ["id", "college_name", "review", "sentence", "aspect", "sentiment", 
              "status", "automated_response", "true_aspect", "true_sentiment"]
    writer.writerow(header)

    for r in rows:
        writer.writerow([
            r.get("id") or "",
            r.get("college_name") or "",
            r.get("review") or "",
            r.get("sentence") or "",
            r.get("aspect") or "",
            r.get("sentiment") or "",
            r.get("status") or "",
            r.get("automated_response") or "",
            r.get("true_aspect") or "",
            r.get("true_sentiment") or ""
        ])

    mem.seek(0)
    return send_file(
        io.BytesIO(mem.getvalue().encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name="reviews_export.csv"
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
