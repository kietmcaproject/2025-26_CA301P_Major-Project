import React, { useState, useEffect } from "react";

/* ------------------ Categories ------------------ */
const scenarioCategories = [
  { id: "conversation", name: "Conversations", emoji: "💬", gradient: "linear-gradient(135deg, #60a5fa, #818cf8)" },
  { id: "daily_life", name: "Daily Life", emoji: "🏠", gradient: "linear-gradient(135deg, #34d399, #6ee7b7)" },
  { id: "workplace", name: "Workplace", emoji: "💼", gradient: "linear-gradient(135deg, #fb923c, #f97316)" },
  { id: "social_events", name: "Social Events", emoji: "🎉", gradient: "linear-gradient(135deg, #f472b6, #f9a8d4)" },
  { id: "school_life", name: "School Life", emoji: "🎓", gradient: "linear-gradient(135deg, #a78bfa, #c4b5fd)" },
  { id: "travel", name: "Travel & Public", emoji: "🚌", gradient: "linear-gradient(135deg, #38bdf8, #22d3ee)" },
  { id: "healthcare", name: "Health & Safety", emoji: "🏥", gradient: "linear-gradient(135deg, #f87171, #ef4444)" },
];

/* ------------------ Scenario Data ------------------ */
const sampleScenarios = [
  {
    id: 1,
    title: "Greeting a New Person",
    description: "Practice introducing yourself politely to someone new.",
    category: "conversation",
    difficulty: "beginner",
    keywords: ["hello", "hi", "my name", "nice to meet"],
    steps: [
      "Smile and make eye contact.",
      'Say, "Hello, my name is [your name]."',
      'Ask, "What is your name?"',
    ],
  },
  {
    id: 2,
    title: "Ordering at a Café",
    description: "Practice ordering food and drinks clearly and politely.",
    category: "daily_life",
    difficulty: "beginner",
    keywords: ["please", "sandwich", "thank you", "coffee"],
    steps: [
      "Look at the menu and decide your order.",
      'Say, "Excuse me, I would like a sandwich, please."',
      "Say thank you when served.",
    ],
  },
  {
    id: 3,
    title: "Talking to a Doctor",
    description: "Explain how you feel to a doctor politely.",
    category: "healthcare",
    difficulty: "intermediate",
    keywords: ["pain", "hurt", "fever", "doctor", "thank you"],
    steps: [
      "Greet the doctor politely.",
      "Describe your symptoms clearly.",
      "Say thank you at the end.",
    ],
  },
  {
    id: 4,
    title: "Asking for Directions",
    description: "Learn how to ask someone for directions politely.",
    category: "travel",
    difficulty: "beginner",
    keywords: ["excuse me", "where", "bus", "thank you"],
    steps: [
      'Say, "Excuse me, can you help me?"',
      "Ask your question clearly.",
      'Say, "Thank you!"',
    ],
  },
  {
    id: 5,
    title: "Introducing Yourself at School",
    description: "Speak confidently in front of classmates.",
    category: "school_life",
    difficulty: "beginner",
    keywords: ["good morning", "my name", "thank you"],
    steps: [
      "Stand confidently.",
      'Say, "Good morning everyone, my name is [your name]."',
      'Finish with, "Thank you!"',
    ],
  },
];

/* ------------------ Helpers ------------------ */
const speakText = (text) => {
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1;
  u.pitch = 1;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(u);
};

const getCategoryStyle = (cat) => {
  const c = scenarioCategories.find((x) => x.id === cat);
  return {
    emoji: c?.emoji || "💬",
    gradient: c?.gradient || "#ddd",
  };
};

const randomMotivation = () => {
  const msgs = [
    "Great effort! 🌟",
    "You’re improving every step! 💪",
    "Awesome — keep practicing! 👍",
    "Perfect tone! Keep it up! 🗣️",
    "That sounded friendly and confident! 😊",
  ];
  return msgs[Math.floor(Math.random() * msgs.length)];
};

/* ------------------ Component ------------------ */
export default function SocialGuide() {
  const [scenarios, setScenarios] = useState([]);
  const [selectedScenario, setSelectedScenario] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [userResponse, setUserResponse] = useState("");
  const [feedback, setFeedback] = useState("");
  const [points, setPoints] = useState(0);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    setScenarios(sampleScenarios);
  }, []);

  const filteredScenarios =
    filter === "all" ? scenarios : scenarios.filter((s) => s.category === filter);

  const startScenario = (s) => {
    setSelectedScenario(s);
    setCurrentStep(0);
    setFeedback("");
    setUserResponse("");
  };

  const handleNext = () => {
    if (currentStep < selectedScenario.steps.length - 1) {
      setCurrentStep(currentStep + 1);
      setFeedback("");
      setUserResponse("");
    } else {
      setFeedback("🎉 You completed this scenario! Great job!");
      speakText("You completed this scenario! Great job!");
    }
  };

  const handleSubmitResponse = () => {
  const response = userResponse.toLowerCase().trim();

  if (!response) {
    setFeedback("💭 Try typing your answer first!");
    speakText("Try typing your answer first!");
    return;
  }

  const keywords = selectedScenario.keywords || [];
  let matched = false;

  // 🔹 Improved: check for partial & semantic matches
  for (const kw of keywords) {
    const regex = new RegExp(kw.replace(/\s+/g, "\\s*"), "i"); // allow minor spacing
    if (regex.test(response)) {
      matched = true;
      break;
    }
  }

  // 🔹 Politeness synonyms (bonus detection)
  const politeWords = ["please", "thank", "thanks", "excuse", "sorry", "welcome"];
  const hasPoliteness = politeWords.some((w) => response.includes(w));

  if (matched || hasPoliteness) {
    const msg = randomMotivation();
    setFeedback(`✅ Great job! You used polite language. ${msg}`);
    setPoints((prev) => prev + 10);
    speakText("Excellent! That was a polite and friendly answer.");
  } else {
    setFeedback(
      "❌ That was okay, but try to include polite words like 'please' or 'thank you'."
    );
    speakText("That was okay, but try to include polite words like please or thank you.");
  }
};


  return (
    <div
      style={{
        padding: "2rem",
        maxWidth: "1000px",
        margin: "0 auto",
        fontFamily: "Inter, sans-serif",
      }}
    >
      <h1 style={{ textAlign: "center", fontWeight: 800 }}>🧠 Social Learning Coach</h1>
      <p style={{ textAlign: "center", color: "#64748b", marginBottom: "1.5rem" }}>
        Practice speaking and social interactions — with personalized feedback!
      </p>

      {!selectedScenario ? (
        <>
          {/* Filter */}
          <div
            style={{
              display: "flex",
              gap: "0.5rem",
              flexWrap: "wrap",
              justifyContent: "center",
              marginBottom: "1rem",
            }}
          >
            <button onClick={() => setFilter("all")} style={{ padding: "0.5rem 1rem" }}>
              All
            </button>
            {scenarioCategories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setFilter(cat.id)}
                style={{ padding: "0.5rem 1rem" }}
              >
                {cat.emoji} {cat.name}
              </button>
            ))}
          </div>

          {/* Scenario Cards */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
              gap: "1rem",
            }}
          >
            {filteredScenarios.map((s) => {
              const { emoji, gradient } = getCategoryStyle(s.category);
              return (
                <div
                  key={s.id}
                  style={{
                    background: gradient,
                    color: "#fff",
                    borderRadius: "1rem",
                    padding: "1rem",
                  }}
                >
                  <h3>
                    {emoji} {s.title}
                  </h3>
                  <p>{s.description}</p>
                  <button
                    onClick={() => startScenario(s)}
                    style={{
                      marginTop: "0.5rem",
                      padding: "0.5rem 1rem",
                      background: "#fff",
                      border: "none",
                      borderRadius: "6px",
                      cursor: "pointer",
                    }}
                  >
                    🎭 Start Practice
                  </button>
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <div
          style={{
            background: "#fff",
            borderRadius: "1rem",
            padding: "1.5rem",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          }}
        >
          <button onClick={() => setSelectedScenario(null)} style={{ marginBottom: "1rem" }}>
            ← Back
          </button>
          <h2>
            {getCategoryStyle(selectedScenario.category).emoji}{" "}
            {selectedScenario.title}
          </h2>

          <h4>Step {currentStep + 1} of {selectedScenario.steps.length}</h4>
          <p
            style={{
              fontSize: "1.1rem",
              background: "#f1f5f9",
              padding: "0.75rem",
              borderRadius: "8px",
            }}
          >
            {selectedScenario.steps[currentStep]}
          </p>

          <div style={{ marginTop: "0.75rem", display: "flex", gap: "0.5rem" }}>
            <button onClick={() => speakText(selectedScenario.steps[currentStep])}>
              🔊 Listen
            </button>
            <button onClick={handleNext}>
              {currentStep === selectedScenario.steps.length - 1
                ? "Finish 🎉"
                : "Next →"}
            </button>
          </div>

          <div style={{ marginTop: "1rem" }}>
            <label>Your Practice Response:</label>
            <textarea
              rows={4}
              value={userResponse}
              onChange={(e) => setUserResponse(e.target.value)}
              style={{
                width: "100%",
                marginTop: "0.5rem",
                borderRadius: "8px",
                padding: "0.5rem",
              }}
            />
            <button onClick={handleSubmitResponse} style={{ marginTop: "0.5rem" }}>
              ✅ Submit Response
            </button>
          </div>

          {feedback && (
            <div
              style={{
                marginTop: "1rem",
                background: feedback.includes("✅")
                  ? "#dcfce7"
                  : feedback.includes("❌")
                  ? "#fee2e2"
                  : "#fef9c3",
                padding: "1rem",
                borderRadius: "8px",
              }}
            >
              <strong>Feedback:</strong>
              <p>{feedback}</p>
            </div>
          )}

          <p style={{ marginTop: "1rem", fontWeight: "bold" }}>⭐ Points: {points}</p>
        </div>
      )}
    </div>
  );
}
