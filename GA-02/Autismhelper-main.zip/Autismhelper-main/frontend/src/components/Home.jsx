import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

// ✅ Use relative imports (since ui folder is inside components)
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";

export default function Home({ setActiveComponent }) {
  const [theme, setTheme] = useState("light");
  const [textSize, setTextSize] = useState(16);
  const [query, setQuery] = useState("");
  const [activeFeature, setActiveFeature] = useState(null);

  useEffect(() => {
    document.documentElement.style.fontSize = `${textSize}px`;
    document.documentElement.dataset.theme = theme;
  }, [textSize, theme]);

  const features = [
    {
      id: "comm",
      title: "Visual Communication",
      subtitle: "AAC boards & quick prompts",
      excerpt:
        "Image-based communication tools for expressing emotions, needs, and thoughts.",
      details:
        "Customizable visual boards with printable templates. Optimized for AAC users and offline access.",
      icon: "💬",
      color: "linear-gradient(135deg, #0ea5e9, #14b8a6)",
    },
    {
      id: "routine",
      title: "Routine Builder",
      subtitle: "Predictable daily structure",
      excerpt:
        "Build step-by-step visual routines with timers, breaks, and gentle reminders.",
      details:
        "Helps individuals reduce anxiety with consistent, easy-to-follow daily visuals.",
      icon: "📅",
      color: "linear-gradient(135deg, #22c55e, #84cc16)",
    },
    {
      id: "learning",
      title: "Learning Studio",
      subtitle: "Adaptive short lessons",
      excerpt:
        "Interactive learning designed for varied attention spans and multi-sensory engagement.",
      details:
        "Includes reading, math, and social lessons that adapt to learning pace and preference.",
      icon: "🎓",
      color: "linear-gradient(135deg, #7c3aed, #6366f1)",
    },
    {
      id: "social",
      title: "Social Skills Lab",
      subtitle: "Guided interactions",
      excerpt:
        "Role-play and scenario practice for real-world social interactions.",
      details:
        "Features customizable scripts, prompts, and reflection points to improve social confidence.",
      icon: "🤝",
      color: "linear-gradient(135deg, #f59e0b, #f97316)",
    },
  ];

  const stats = [
    { label: "Active members", value: 1200 },
    { label: "Avg session (mins)", value: 18 },
    { label: "Tools used daily", value: 4 },
  ];

  function speak(text) {
    if (!window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 0.95;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background:
          theme === "light"
            ? "linear-gradient(to bottom, #ffffff, #f8fafc)"
            : "linear-gradient(to bottom, #0f172a, #1e293b)",
        color: theme === "light" ? "#1e293b" : "#f1f5f9",
        transition: "all 0.4s ease",
        fontFamily:
          "'Inter', 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
        paddingBottom: "4rem",
      }}
    >
      {/* === Floating Controls === */}
      <div
        style={{
          position: "fixed",
          right: "1rem",
          top: "1rem",
          display: "flex",
          flexDirection: "column",
          gap: "0.5rem",
          zIndex: 50,
        }}
      >
        <button
          onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          style={controlBtn}
          title="Toggle theme"
        >
          {theme === "light" ? "🌙" : "☀️"}
        </button>
        <button
          onClick={() => setTextSize((s) => Math.max(14, s - 1))}
          style={controlBtn}
          title="Decrease font size"
        >
          A-
        </button>
        <button
          onClick={() => setTextSize((s) => Math.min(20, s + 1))}
          style={controlBtn}
          title="Increase font size"
        >
          A+
        </button>
      </div>

      {/* === Header === */}
      <header
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "2rem 1.5rem 1rem",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
            <div
              style={{
                background: "linear-gradient(135deg, #0ea5e9, #14b8a6)",
                borderRadius: "0.75rem",
                padding: "0.5rem",
              }}
            >
              <Avatar>
                <div
                  style={{
                    height: "2rem",
                    width: "2rem",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: "1.5rem",
                  }}
                >
                  🧩
                </div>
              </Avatar>
            </div>
            <div>
              <h1 style={{ fontSize: "1.5rem", fontWeight: 800 }}>
                Autism Support Hub
              </h1>
              <p style={{ color: "#64748b", fontSize: "0.9rem" }}>
                Tools, learning & support — designed with care.
              </p>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.75rem",
              flexWrap: "wrap",
            }}
          >
            <Input
              placeholder="Search tools or topics"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{ width: "16rem" }}
            />
            <Button onClick={() => speak(query || "Welcome to Autism Hub")}>
              🔊 Speak
            </Button>
            {/* <Button onClick={() => setActiveComponent("login")}>Sign in</Button> */}
          </div>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          style={{
            marginTop: "2rem",
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: "2rem",
            alignItems: "center",
          }}
        >
          <div>
            <h2 style={{ fontSize: "2rem", fontWeight: 800 }}>
              Practical tools for everyday life — made simple.
            </h2>
            <p style={{ color: "#64748b", marginTop: "0.5rem" }}>
              Build predictable routines, communicate clearly, and learn with
              short, adaptive lessons.
            </p>
            <div style={{ display: "flex", gap: "0.75rem", marginTop: "1rem" }}>
              {/* <Button onClick={() => setActiveComponent("explore")}>
                Explore tools
              </Button> */}
              {/* <Button
                variant="outline"
                onClick={() => setActiveComponent("community")}
              >
                
              </Button> */}
            </div>

            <div
              style={{
                marginTop: "1.5rem",
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))",
                gap: "0.75rem",
              }}
            >
              {stats.map((s) => (
                <Card key={s.label}>
                  <CardContent
                    style={{
                      padding: "0.75rem",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                    }}
                  >
                    <div
                      style={{
                        fontSize: "1rem",
                        fontWeight: 700,
                        color: "#0ea5e9",
                      }}
                    >
                      {s.value}
                    </div>
                    <div
                      style={{
                        fontSize: "0.85rem",
                        color:
                          theme === "light"
                            ? "#475569"
                            : "rgba(255,255,255,0.7)",
                      }}
                    >
                      {s.label}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div
            style={{
              background:
                theme === "light"
                  ? "linear-gradient(135deg, #f1f5f9, #ffffff)"
                  : "linear-gradient(135deg, #1e293b, #334155)",
              padding: "1.5rem",
              borderRadius: "1rem",
              boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
            }}
          >
            <h3 style={{ fontWeight: 700, marginBottom: "0.5rem" }}>
              Quick Actions
            </h3>
            <p
              style={{
                fontSize: "0.9rem",
                color:
                  theme === "light" ? "#475569" : "rgba(255,255,255,0.75)",
                marginBottom: "1rem",
              }}
            >
              Create a new routine, launch ARIA, or open Emotion & Communication Aid
              boards.
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "0.5rem",
              }}
            >
              <Button onClick={() => setActiveComponent("routine")}>
                Create Routine
              </Button>
              <Button
                variant="outline"
                onClick={() => setActiveComponent("assistant")}
              >
                Open ARIA
              </Button>
              <Button
                variant="ghost"
                onClick={() => setActiveComponent("communication")}
              >
                Emotion & Communication Aid
              </Button>
            </div>
          </div>
        </motion.section>
      </header>

      {/* === Feature Cards === */}
      <main
        style={{
          maxWidth: "1200px",
          margin: "0 auto",
          padding: "2rem 1.5rem",
        }}
      >
        <h2
          style={{
            fontSize: "1.5rem",
            fontWeight: 800,
            marginBottom: "1rem",
          }}
        >
          Featured Tools
        </h2>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
            gap: "1.25rem",
          }}
        >
          {features.map((f) => (
            <motion.div
              key={f.id}
              whileHover={{ y: -5 }}
              style={{
                background: f.color,
                borderRadius: "1rem",
                color: "#fff",
                padding: "1.25rem",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
                cursor: "pointer",
              }}
              onClick={() => setActiveComponent(f.id)}
            >
              <div style={{ fontSize: "2rem" }}>{f.icon}</div>
              <h3
                style={{
                  fontSize: "1.25rem",
                  fontWeight: 700,
                  marginTop: "0.5rem",
                }}
              >
                {f.title}
              </h3>
              <p
                style={{
                  fontSize: "0.9rem",
                  opacity: 0.9,
                  marginTop: "0.25rem",
                }}
              >
                {f.excerpt}
              </p>
              <div
                style={{
                  display: "flex",
                  gap: "0.5rem",
                  marginTop: "0.75rem",
                }}
              >
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    speak(f.details);
                  }}
                >
                  🔊 Listen
                </Button>
                <Button
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    setActiveComponent(f.id);
                  }}
                >
                  Open
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <section
          style={{
            marginTop: "3rem",
            padding: "2rem",
            background: "linear-gradient(90deg, #0ea5e9, #14b8a6)",
            borderRadius: "1.25rem",
            color: "#fff",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "1rem",
          }}
        >
          <div>
            <h3 style={{ fontSize: "1.25rem", fontWeight: 800 }}>
              Need a friendly guide?
            </h3>
            <p style={{ fontSize: "0.9rem", opacity: 0.9 }}>
              ARIA can help create routines, visualize conversations, or
              practice scenarios.
            </p>
          </div>
          <div style={{ display: "flex", gap: "0.75rem" }}>
            <Button onClick={() => setActiveComponent("assistant")}>
              Chat with ARIA
            </Button>
            <Button
              variant="outline"
              style={{ color: "#fff", borderColor: "#fff" }}
              onClick={() => setActiveComponent("help")}
            >
              Help & Tutorials
            </Button>
          </div>
        </section>

        {/* Footer */}
              {/* Footer */}
        <footer
          style={{
            marginTop: "4rem",
            background:
              theme === "light"
                ? "linear-gradient(to right, #f8fafc, #e2e8f0)"
                : "linear-gradient(to right, #1e293b, #0f172a)",
            color: theme === "light" ? "#1e293b" : "#f1f5f9",
            padding: "2rem 1.5rem",
            textAlign: "center",
            borderTop:
              theme === "light"
                ? "1px solid #e2e8f0"
                : "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <div style={{ maxWidth: "900px", margin: "0 auto" }}>
            <h3>🌈 Autism Support Hub</h3>
            <p>
              Empowering individuals and families with adaptive tools,
              emotional support, and inclusive technology.
            </p>
            <p style={{ opacity: 0.6, fontSize: "0.85rem", marginTop: "1rem" }}>
              © {new Date().getFullYear()} Autism Support Hub — Built with empathy 💙
            </p>
          </div>
        </footer>

      </main>
    </div>
  );
}

const controlBtn = {
  padding: "0.5rem 0.6rem",
  borderRadius: "9999px",
  border: "1px solid rgba(0,0,0,0.1)",
  background: "#fff",
  boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
  cursor: "pointer",
  fontWeight: 700,
};
