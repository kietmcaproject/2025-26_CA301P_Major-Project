import React, { useState, useEffect } from "react";

const Community = ({ setActiveComponent }) => {
  const [darkMode, setDarkMode] = useState(false);
  const [fontSize, setFontSize] = useState(18);
  const [isLoaded, setIsLoaded] = useState(false);
  const [activeTab, setActiveTab] = useState("forums");

  const forums = [
    {
      id: 1,
      title: "Daily Check-in",
      description: "Share how you're feeling today",
      members: 234,
      posts: 1520,
      icon: "☀️"
    },
    {
      id: 2,
      title: "Success Stories",
      description: "Celebrate achievements big and small",
      members: 189,
      posts: 892,
      icon: "🌟"
    },
    {
      id: 3,
      title: "Parent Support",
      description: "Connect with other parents and caregivers",
      members: 456,
      posts: 2103,
      icon: "👨‍👩‍👧‍👦"
    },
    {
      id: 4,
      title: "Adult Autism",
      description: "For autistic adults to share experiences",
      members: 312,
      posts: 1456,
      icon: "🧑‍💼"
    },
    {
      id: 5,
      title: "Sensory Strategies",
      description: "Tips and tricks for sensory management",
      members: 167,
      posts: 734,
      icon: "🎧"
    },
    {
      id: 6,
      title: "Questions & Answers",
      description: "Get help from community members",
      members: 523,
      posts: 2891,
      icon: "❓"
    }
  ];

  const events = [
    {
      id: 1,
      title: "Virtual Coffee Meetup",
      date: "Every Tuesday",
      time: "3:00 PM EST",
      type: "Weekly",
      icon: "☕"
    },
    {
      id: 2,
      title: "Art Therapy Session",
      date: "First Saturday",
      time: "2:00 PM EST",
      type: "Monthly",
      icon: "🎨"
    },
    {
      id: 3,
      title: "Parent Support Group",
      date: "Every Thursday",
      time: "7:00 PM EST",
      type: "Weekly",
      icon: "👥"
    },
    {
      id: 4,
      title: "Social Skills Workshop",
      date: "Third Wednesday",
      time: "4:00 PM EST",
      type: "Monthly",
      icon: "🤝"
    }
  ];

  const stories = [
    {
      id: 1,
      author: "Sarah M.",
      title: "Finding My Voice",
      excerpt: "Learning to communicate differently changed my life...",
      date: "2 days ago",
      likes: 45,
      icon: "💬"
    },
    {
      id: 2,
      author: "James T.",
      title: "My First Job Success",
      excerpt: "With the right accommodations, I'm thriving at work...",
      date: "1 week ago",
      likes: 89,
      icon: "💼"
    },
    {
      id: 3,
      author: "Alex K.",
      title: "Building Friendships",
      excerpt: "Social skills practice helped me find my people...",
      date: "2 weeks ago",
      likes: 67,
      icon: "👥"
    }
  ];

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className={`community-container ${darkMode ? "dark" : ""} ${isLoaded ? "loaded" : ""}`} style={{ fontSize: `${fontSize}px` }}>
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .community-container {
          min-height: 100vh;
          background: ${darkMode 
            ? 'linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)' 
            : 'linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%)'};
          color: ${darkMode ? '#f1f5f9' : '#334155'};
          font-family: 'Inter', 'Segoe UI', system-ui, sans-serif;
          line-height: 1.6;
          transition: all 0.3s ease;
          opacity: 0;
          transform: translateY(20px);
        }

        .community-container.loaded {
          opacity: 1;
          transform: translateY(0);
          transition: opacity 0.5s ease, transform 0.5s ease;
        }

        .header {
          padding: 2rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          max-width: 1200px;
          margin: 0 auto;
        }

        .back-button {
          background: ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: 12px;
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          transition: all 0.3s ease;
        }

        .back-button:hover {
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.1)'};
        }

        .page-title {
          font-size: 2rem;
          font-weight: 700;
          color: ${darkMode ? '#f1f5f9' : '#1e293b'};
        }

        .controls {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .font-control {
          display: flex;
          gap: 0.5rem;
          align-items: center;
          background: ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          padding: 0.5rem;
          border-radius: 30px;
        }

        .font-btn {
          background: transparent;
          border: none;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          cursor: pointer;
          font-weight: bold;
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
        }

        .font-btn:hover {
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.2)'};
        }

        .theme-toggle {
          background: ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          border: none;
          width: 60px;
          height: 30px;
          border-radius: 15px;
          position: relative;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .theme-toggle-slider {
          position: absolute;
          top: 3px;
          left: ${darkMode ? '30px' : '3px'};
          width: 24px;
          height: 24px;
          background: ${darkMode ? '#a78bfa' : '#6366f1'};
          border-radius: 50%;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
        }

        .main-content {
          max-width: 1200px;
          margin: 0 auto;
          padding: 2rem;
        }

        .welcome-banner {
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.1)'};
          border: 1px solid ${darkMode ? 'rgba(167, 139, 250, 0.3)' : 'rgba(99, 102, 241, 0.2)'};
          border-radius: 20px;
          padding: 2rem;
          margin-bottom: 2rem;
          text-align: center;
        }

        .welcome-title {
          font-size: 1.8rem;
          font-weight: 600;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          margin-bottom: 1rem;
        }

        .welcome-description {
          color: ${darkMode ? '#cbd5e1' : '#64748b'};
          max-width: 600px;
          margin: 0 auto;
        }

        .community-stats {
          display: flex;
          justify-content: center;
          gap: 3rem;
          margin-top: 1.5rem;
        }

        .stat-item {
          text-align: center;
        }

        .stat-number {
          font-size: 2rem;
          font-weight: 700;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
        }

        .stat-label {
          font-size: 0.9rem;
          color: ${darkMode ? '#94a3b8' : '#64748b'};
        }

        .tabs {
          display: flex;
          gap: 1rem;
          margin-bottom: 2rem;
          border-bottom: 1px solid ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
        }

        .tab-button {
          background: transparent;
          border: none;
          padding: 1rem 1.5rem;
          cursor: pointer;
          color: ${darkMode ? '#94a3b8' : '#64748b'};
          font-weight: 500;
          transition: all 0.3s ease;
          border-bottom: 3px solid transparent;
        }

        .tab-button:hover {
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
        }

        .tab-button.active {
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          border-bottom-color: ${darkMode ? '#a78bfa' : '#6366f1'};
        }

        .tab-content {
          animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .forums-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
          gap: 1.5rem;
        }

        .forum-card {
          background: ${darkMode ? 'rgba(30, 41, 59, 0.7)' : 'rgba(255, 255, 255, 0.7)'};
          border: 1px solid ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          border-radius: 16px;
          padding: 1.5rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .forum-card:hover {
          transform: translateY(-3px);
          box-shadow: ${darkMode 
            ? '0 10px 30px rgba(0, 0, 0, 0.3)' 
            : '0 10px 30px rgba(0, 0, 0, 0.1)'};
        }

        .forum-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 1rem;
        }

        .forum-icon {
          font-size: 2rem;
          width: 50px;
          height: 50px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.1)'};
          border-radius: 12px;
        }

        .forum-title {
          font-size: 1.2rem;
          font-weight: 600;
          color: ${darkMode ? '#f1f5f9' : '#1e293b'};
        }

        .forum-description {
          color: ${darkMode ? '#94a3b8' : '#64748b'};
          margin-bottom: 1rem;
        }

        .forum-stats {
          display: flex;
          gap: 1rem;
          font-size: 0.9rem;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
        }

        .events-list {
          display: grid;
          gap: 1rem;
        }

        .event-card {
          background: ${darkMode ? 'rgba(30, 41, 59, 0.7)' : 'rgba(255, 255, 255, 0.7)'};
          border: 1px solid ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          border-radius: 16px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1.5rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .event-card:hover {
          transform: translateX(5px);
          box-shadow: ${darkMode 
            ? '0 10px 30px rgba(0, 0, 0, 0.3)' 
            : '0 10px 30px rgba(0, 0, 0, 0.1)'};
        }

        .event-icon {
          font-size: 2.5rem;
          width: 60px;
          height: 60px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.1)'};
          border-radius: 12px;
        }

        .event-details {
          flex: 1;
        }

        .event-title {
          font-size: 1.2rem;
          font-weight: 600;
          color: ${darkMode ? '#f1f5f9' : '#1e293b'};
          margin-bottom: 0.5rem;
        }

        .event-info {
          color: ${darkMode ? '#94a3b8' : '#64748b'};
          font-size: 0.9rem;
        }

        .event-type {
          background: ${darkMode ? 'rgba(167, 139, 250, 0.2)' : 'rgba(99, 102, 241, 0.1)'};
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          padding: 0.25rem 0.75rem;
          border-radius: 12px;
          font-size: 0.85rem;
        }

        .stories-grid {
          display: grid;
          gap: 1.5rem;
        }

        .story-card {
          background: ${darkMode ? 'rgba(30, 41, 59, 0.7)' : 'rgba(255, 255, 255, 0.7)'};
          border: 1px solid ${darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.05)'};
          border-radius: 16px;
          padding: 1.5rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .story-card:hover {
          transform: translateY(-3px);
          box-shadow: ${darkMode 
            ? '0 10px 30px rgba(0, 0, 0, 0.3)' 
            : '0 10px 30px rgba(0, 0, 0, 0.1)'};
        }

        .story-header {
          display: flex;
          justify-content: space-between;
          align-items: start;
          margin-bottom: 1rem;
        }

        .story-title {
          font-size: 1.2rem;
          font-weight: 600;
          color: ${darkMode ? '#f1f5f9' : '#1e293b'};
          margin-bottom: 0.25rem;
        }

        .story-author {
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
          font-size: 0.9rem;
        }

        .story-date {
          color: ${darkMode ? '#94a3b8' : '#64748b'};
          font-size: 0.85rem;
        }

        .story-excerpt {
          color: ${darkMode ? '#cbd5e1' : '#64748b'};
          margin-bottom: 1rem;
        }

        .story-footer {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .story-likes {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: ${darkMode ? '#a78bfa' : '#6366f1'};
        }

        @media (max-width: 768px) {
          .forums-grid {
            grid-template-columns: 1fr;
          }
          
          .community-stats {
            gap: 1.5rem;
          }
          
          .tabs {
            overflow-x: auto;
          }
        }
      `}</style>

      {/* Header */}
      <header className="header">
        <button className="back-button" onClick={() => setActiveComponent("home")}>
          ← Back to Home
        </button>
        <h1 className="page-title">👥 Community</h1>
        <div className="controls">
          <div className="font-control">
            <button className="font-btn" onClick={() => setFontSize(Math.max(14, fontSize - 2))}>A-</button>
            <button className="font-btn" onClick={() => setFontSize(18)}>A</button>
            <button className="font-btn" onClick={() => setFontSize(Math.min(24, fontSize + 2))}>A+</button>
          </div>
          <button 
            className="theme-toggle"
            onClick={() => setDarkMode(!darkMode)}
          >
            <div className="theme-toggle-slider">
              {darkMode ? '🌙' : '☀️'}
            </div>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Welcome Banner */}
        <div className="welcome-banner">
          <h2 className="welcome-title">Welcome to Our Community</h2>
          <p className="welcome-description">
            Connect with others who understand. Share experiences, find support, and build meaningful relationships in a safe, inclusive space.
          </p>
          <div className="community-stats">
            <div className="stat-item">
              <div className="stat-number">2,847</div>
              <div className="stat-label">Members</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">156</div>
              <div className="stat-label">Online Now</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">89</div>
              <div className="stat-label">New Today</div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="tabs">
          <button 
            className={`tab-button ${activeTab === 'forums' ? 'active' : ''}`}
            onClick={() => setActiveTab('forums')}
          >
            Forums
          </button>
          <button 
            className={`tab-button ${activeTab === 'events' ? 'active' : ''}`}
            onClick={() => setActiveTab('events')}
          >
            Events
          </button>
          <button 
            className={`tab-button ${activeTab === 'stories' ? 'active' : ''}`}
            onClick={() => setActiveTab('stories')}
          >
            Success Stories
          </button>
        </div>

        {/* Tab Content */}
        <div className="tab-content">
          {activeTab === 'forums' && (
            <div className="forums-grid">
              {forums.map((forum) => (
                <div key={forum.id} className="forum-card">
                  <div className="forum-header">
                    <div className="forum-icon">{forum.icon}</div>
                    <h3 className="forum-title">{forum.title}</h3>
                  </div>
                  <p className="forum-description">{forum.description}</p>
                  <div className="forum-stats">
                    <span>👥 {forum.members} members</span>
                    <span>💬 {forum.posts} posts</span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'events' && (
            <div className="events-list">
              {events.map((event) => (
                <div key={event.id} className="event-card">
                  <div className="event-icon">{event.icon}</div>
                  <div className="event-details">
                    <h3 className="event-title">{event.title}</h3>
                    <p className="event-info">{event.date} at {event.time}</p>
                  </div>
                  <span className="event-type">{event.type}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'stories' && (
            <div className="stories-grid">
              {stories.map((story) => (
                <div key={story.id} className="story-card">
                  <div className="story-header">
                    <div>
                      <h3 className="story-title">{story.title}</h3>
                      <p className="story-author">by {story.author}</p>
                    </div>
                    <span className="story-date">{story.date}</span>
                  </div>
                  <p className="story-excerpt">{story.excerpt}</p>
                  <div className="story-footer">
                    <div className="story-likes">
                      <span>❤️</span>
                      <span>{story.likes}</span>
                    </div>
                    <button className="font-btn">Read More →</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Community;