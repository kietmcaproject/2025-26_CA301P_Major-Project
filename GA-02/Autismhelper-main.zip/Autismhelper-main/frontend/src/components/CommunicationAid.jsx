import React, { useState, useEffect, useRef } from "react";

/**
 * CommunicationAid.jsx
 * - Emotion buttons + spoken suggestions
 * - Calm Mode with breathing and ambient sound
 * - Mood logging (moodLog)
 * - Analytics (simple)
 * - Mood Journal (write, tag mood, view, delete, export)
 * - All data saved to localStorage
 */

export default function CommunicationAid() {
  // UI states
  const [darkMode, setDarkMode] = useState(false);
  const [spokenCount, setSpokenCount] = useState(0);
  const [emotion, setEmotion] = useState(null);
  const [feedback, setFeedback] = useState("");
  const [calmMode, setCalmMode] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [popupSuggestions, setPopupSuggestions] = useState([]);
  const [breathStep, setBreathStep] = useState("Breathe In…");
  const [moodLog, setMoodLog] = useState(() => JSON.parse(localStorage.getItem("moodLog")) || []);
  const [calmStreak, setCalmStreak] = useState(() => Number(localStorage.getItem("calmStreak")) || 0);

  // Mood Journal states
  const [showJournal, setShowJournal] = useState(false);
  const [journalEntries, setJournalEntries] = useState(() => JSON.parse(localStorage.getItem("journalEntries")) || []);
  const [journalText, setJournalText] = useState("");
  const [journalMood, setJournalMood] = useState("calm");
  const [journalDate, setJournalDate] = useState(() => new Date().toISOString().slice(0, 10)); // YYYY-MM-DD

  const audioRef = useRef(null);

  // color scheme
  const colors = {
    background: darkMode ? "#0f172a" : "#e8f5e9",
    card: darkMode ? "#1e293b" : "#ffffff",
    text: darkMode ? "#e2e8f0" : "#1b5e20",
    accent: darkMode ? "#48c9b0" : "#4db6ac",
  };

  // Ambient audio for Calm Mode
  useEffect(() => {
    audioRef.current = new Audio("https://cdn.pixabay.com/download/audio/2022/03/15/audio_f7c5ec8c60.mp3?filename=forest-ambience-140704.mp3");
    audioRef.current.loop = true;
    audioRef.current.volume = 0.25;
    return () => audioRef.current?.pause();
  }, []);

  useEffect(() => {
    calmMode ? audioRef.current?.play().catch(() => {}) : audioRef.current?.pause();
  }, [calmMode]);

  // persist moodLog, journalEntries, calmStreak
  useEffect(() => localStorage.setItem("moodLog", JSON.stringify(moodLog)), [moodLog]);
  useEffect(() => localStorage.setItem("journalEntries", JSON.stringify(journalEntries)), [journalEntries]);
  useEffect(() => localStorage.setItem("calmStreak", String(calmStreak)), [calmStreak]);

  // speak helper
  const speak = (text, rate = 0.85) => {
    if (!("speechSynthesis" in window)) return;
    const s = new SpeechSynthesisUtterance(text);
    s.lang = "en-US";
    s.rate = rate;
    s.pitch = 1;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(s);
  };

  // Emotion handling: logs mood, shows suggestions, maybe starts calm mode
  const handleEmotion = (emotionText) => {
    setEmotion(emotionText);
    setSpokenCount((n) => n + 1);

    // log mood
    const entry = {
      mood: emotionText,
      time: new Date().toLocaleTimeString(),
      day: new Date().toLocaleDateString()
    };
    setMoodLog((prev) => [...prev, entry]);

    // speak the emotion word (short) and add feedback
    speak(emotionText);
    if (emotionText === "happy") setFeedback("That's wonderful! 💚");
    else setFeedback("");

    // suggestions & popup for certain emotions
   const suggestions = getSuggestions(emotionText);
if (suggestions.length > 0) {
  setPopupSuggestions(suggestions);
  setShowPopup(true);
}


    // trigger calm mode for high-intensity emotions
    if (emotionText === "angry" || emotionText === "scared") setCalmMode(true);
  };

 const getSuggestions = (m) => {
  switch (m) {
    case "happy":
      return [
        "Smile and enjoy this moment",
        "Share your happiness with someone",
        "Do something creative",
      ];

    case "sad":
      return [
        "Take a deep breath",
        "Listen to a favorite song",
        "Talk to someone you trust",
      ];

    case "angry":
      return [
        "Take slow deep breaths",
        "Count slowly to ten",
        "Drink some water",
      ];

    case "scared":
      return [
        "You are safe now",
        "Turn on a light",
        "Call someone you trust",
      ];

    case "tired":
      return [
        "Close your eyes for a minute",
        "Drink water",
        "Stretch gently",
      ];

    case "confused":
      return [
        "Pause and breathe slowly",
        "Write your thoughts down",
        "Ask someone for help",
      ];

    case "excited":
      return [
        "Take a deep breath",
        "Share your excitement",
        "Enjoy the moment",
      ];

    case "calm":
      return [
        "Maintain slow breathing",
        "Stay present",
        "Enjoy the calm feeling",
      ];

    case "bored":
      return [
        "Change your activity",
        "Listen to music",
        "Try something new",
      ];

    case "relaxed":
      return [
        "Continue relaxing",
        "Stretch gently",
        "Stay in the moment",
      ];

    case "frustrated":
      return [
        "Pause and breathe deeply",
        "Take a short break",
        "Break the task into steps",
      ];

    default:
      return [];
  }
};

  // Calm breathing cycle
  useEffect(() => {
    if (!calmMode) return;
    let step = 0;
    const steps = ["Breathe In…", "Hold…", "Exhale…", "Hold…"];
    const interval = setInterval(() => {
      setBreathStep(steps[step]);
      speak(steps[step], 0.95);
      step = (step + 1) % steps.length;
    }, 5000);
    return () => clearInterval(interval);
  }, [calmMode]);

  // complete calm action
  const handleCalmComplete = () => {
    setCalmMode(false);
    setCalmStreak((s) => s + 1);
    setFeedback("You did great calming yourself 🌈");
    speak("You did great calming yourself", 0.9);
    // add a calm mood log entry
    setMoodLog((p) => [...p, { mood: "calm", time: new Date().toLocaleTimeString(), day: new Date().toLocaleDateString() }]);
  };

  // === Mood Journal functions ===
  const saveJournalEntry = () => {
    if (!journalText.trim()) {
      speak("Please write something first");
      return;
    }
    const newEntry = {
      id: Date.now(),
      date: journalDate, // YYYY-MM-DD
      mood: journalMood,
      text: journalText.trim(),
      time: new Date().toLocaleTimeString()
    };
    setJournalEntries((prev) => [...prev, newEntry]);
    setJournalText("");
    speak("Saved your journal entry");
    setFeedback("Journal saved ✔️");
    // optional: also add to moodLog for analytics
    setMoodLog((prev) => [...prev, { mood: journalMood, time: new Date().toLocaleTimeString(), day: journalDate }]);
  };

  const deleteJournalEntry = (id) => {
    setJournalEntries((prev) => prev.filter((e) => e.id !== id));
    speak("Entry deleted");
  };

  const exportJournal = () => {
    const dataStr = JSON.stringify(journalEntries, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mood-journal-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    speak("Exported journal. Check your downloads folder.");
  };

  // Simple analytics: group moodLog by day and show counts
  const groupByDay = () => {
    const counts = {};
    moodLog.forEach((entry) => {
      if (!counts[entry.day]) counts[entry.day] = { day: entry.day, calm: 0, happy: 0, sad: 0, angry: 0, scared: 0, tired: 0, excited: 0, confused: 0, bored: 0, relaxed: 0, frustrated: 0 };
      counts[entry.day][entry.mood] = (counts[entry.day][entry.mood] || 0) + 1;
    });
    // return last 7 days (sorted)
    return Object.values(counts).sort((a,b) => new Date(a.day) - new Date(b.day)).slice(-7);
  };

  const recentMood = moodLog.length ? moodLog[moodLog.length - 1].mood : null;

  // Emotion palette / categories (expanded)
  const categories = [
    {
      title: "💭 Emotions",
      color: "#a5d6a7",
      items: [
        { emoji: "😊", text: "happy" },
        { emoji: "😢", text: "sad" },
        { emoji: "😠", text: "angry" },
        { emoji: "😨", text: "scared" },
        { emoji: "😴", text: "tired" },
        { emoji: "😕", text: "confused" },
        { emoji: "🤗", text: "excited" },
        { emoji: "🕊️", text: "calm" },
        { emoji: "😐", text: "bored" },
        { emoji: "😌", text: "relaxed" },
        { emoji: "😤", text: "frustrated" },
      ],
    },
  ];

  // Small helper to clear voice
  const stopVoice = () => window.speechSynthesis.cancel();

  // download mood log
  const exportMoodLog = () => {
    const dataStr = JSON.stringify(moodLog, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mood-log-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    speak("Mood log exported");
  };

  // UI helpers (styles)
  const btnStyle = {
    background: colors.accent,
    border: "none",
    color: "#fff",
    borderRadius: 8,
    padding: "10px 12px",
    cursor: "pointer",
    width: "100%",
    textAlign: "left"
  };

  const sectionStyle = (bg) => ({
    background: bg,
    borderRadius: 12,
    padding: 16,
    boxShadow: "0 4px 10px rgba(0,0,0,0.08)",
    marginBottom: 16
  });

  const popupOverlay = {
    position: "fixed", top: 0, left: 0, width: "100%", height: "100%", background: "rgba(0,0,0,0.5)",
    display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1200
  };

  const popupBox = {
    background: "#fff", borderRadius: 12, padding: 20, maxWidth: 420, width: "90%", boxShadow: "0 6px 20px rgba(0,0,0,0.3)"
  };

  // Render
  return (
    <div style={{ minHeight: "100vh", background: colors.background, color: colors.text, display: "flex", fontFamily: "Nunito, sans-serif" }}>
      {/* Sidebar */}
      <aside style={{ width: 240, background: colors.card, padding: 16, borderRight: `3px solid ${colors.accent}`, display: "flex", flexDirection: "column", gap: 12 }}>
        <h2 style={{ textAlign: "center", margin: 0 }}>🧭 Dashboard</h2>
        <button style={btnStyle} onClick={() => { setShowAnalytics(false); setShowJournal(false); setCalmMode(false); }}>
          🏠 Home
        </button>
        <button style={btnStyle} onClick={() => { setShowAnalytics(false); setShowJournal(false); setCalmMode(true); }}>
          🌿 Calm Mode
        </button>
        <button style={btnStyle} onClick={() => { setShowAnalytics(true); setShowJournal(false); setCalmMode(false); }}>
          📊 Analytics
        </button>
        <button style={btnStyle} onClick={() => { setShowJournal(true); setShowAnalytics(false); setCalmMode(false); }}>
          📔 Mood Journal
        </button>
        <button style={btnStyle} onClick={() => setDarkMode((d) => !d)}>
          {darkMode ? "☀️ Light" : "🌙 Dark"}
        </button>
        <button style={btnStyle} onClick={stopVoice}>🔇 Stop Voice</button>

        <div style={{ marginTop: "auto" }}>
          <div style={{ fontSize: 13, opacity: 0.9 }}>Recent mood: <strong>{recentMood || "—"}</strong></div>
          <div style={{ marginTop: 8, fontSize: 13 }}>Calm streak: <strong>{calmStreak}</strong></div>
          <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
            <button onClick={exportMoodLog} style={{ flex: 1, padding: 8, borderRadius: 8, border: "none", background: "#9CCC65", color: "#fff", cursor: "pointer" }}>Export Log</button>
            <button onClick={() => { setMoodLog([]); setJournalEntries([]); setCalmStreak(0); speak("Data cleared"); }} style={{ padding: 8, borderRadius: 8, border: "none", background: "#EF5350", color: "#fff", cursor: "pointer" }}>Clear</button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main style={{ flex: 1, padding: 20 }}>
        <header style={{ textAlign: "center", marginBottom: 16 }}>
          <h1 style={{ margin: 0 }}>💬 Emotion & Communication Aid</h1>
          <p style={{ marginTop: 6, opacity: 0.9 }}>Express, reflect, and practice calming — built for sensory safety.</p>
        </header>

        {/* Home / Emotions */}
        {!calmMode && !showAnalytics && !showJournal && (
          <>
            {categories.map((cat, i) => (
              <section key={i} style={sectionStyle(colors.card)}>
                <h2 style={{ color: cat.color, textAlign: "center", marginTop: 0 }}>{cat.title}</h2>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: 12, marginTop: 12 }}>
                  {cat.items.map((item, idx) => (
                    <button key={idx} onClick={() => handleEmotion(item.text)} style={{ background: cat.color, border: "none", borderRadius: 12, padding: 12, color: "#fff", fontSize: 16, cursor: "pointer" }}>
                      <div style={{ fontSize: 24 }}>{item.emoji}</div>
                      <div style={{ marginTop: 6, textTransform: "capitalize" }}>{item.text}</div>
                    </button>
                  ))}
                </div>
              </section>
            ))}

            {/* Quick feedback / actions */}
            <section style={sectionStyle(colors.card)}>
              <div style={{ display: "flex", gap: 12, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap" }}>
                <div>
                  <strong>Recent feedback:</strong> <span style={{ marginLeft: 8 }}>{feedback || "—"}</span>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => speak("You are safe. Take a calm breath")} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#4DB6AC", color: "#fff", cursor: "pointer" }}>Quick Calm</button>
                  <button onClick={() => { setFeedback(""); stopVoice(); }} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#90A4AE", color: "#fff", cursor: "pointer" }}>Clear</button>
                </div>
              </div>
            </section>
          </>
        )}

        {/* Calm Mode */}
        {calmMode && (
          <section style={{ textAlign: "center", marginTop: 40 }}>
            <div style={{ width: 220, height: 220, margin: "0 auto", borderRadius: "50%", background: "#A5D6A7", boxShadow: "0 10px 30px rgba(0,0,0,0.12)", animation: "breathe 6s ease-in-out infinite" }} />
            <h2 style={{ marginTop: 16 }}>{breathStep}</h2>
            <div style={{ marginTop: 16 }}>
              <button onClick={handleCalmComplete} style={{ padding: "10px 18px", borderRadius: 10, border: "none", background: "#4CAF50", color: "#fff", cursor: "pointer" }}>🕊️ I'm Calm Now</button>
              <button onClick={() => { setCalmMode(false); stopVoice(); }} style={{ marginLeft: 12, padding: "10px 18px", borderRadius: 10, border: "none", background: "#90A4AE", color: "#fff", cursor: "pointer" }}>Exit</button>
            </div>
          </section>
        )}

        {/* Analytics */}
        {showAnalytics && (
          <section style={sectionStyle(colors.card)}>
            <h2>📈 Mood Overview (last 7 days)</h2>
            {groupByDay().length === 0 ? <p>No mood data yet.</p> : (
              groupByDay().map((d, idx) => {
                const total = Object.values(d).slice(1).reduce((a,b) => a + b, 0) || 1;
                return (
                  <div key={idx} style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <strong>{d.day}</strong>
                      <small>{total} entries</small>
                    </div>
                    <div style={{ display: "flex", height: 18, borderRadius: 8, overflow: "hidden", background: "#f1f1f1" }}>
                      {["calm","happy","sad","angry","scared","tired","excited","confused","bored","relaxed","frustrated"].map((k) => {
                        const val = d[k] || 0;
                        const flex = val;
                        const colorMap = { calm:"#AED581", happy:"#81C784", sad:"#64B5F6", angry:"#E57373", scared:"#BA68C8", tired:"#FFCC80", excited:"#FFD54F", confused:"#90A4AE", bored:"#B0BEC5", relaxed:"#C5E1A5", frustrated:"#FFAB91" };
                        return flex > 0 ? <div key={k} style={{ flex: flex, background: colorMap[k] || "#ddd" }} /> : null;
                      })}
                    </div>
                  </div>
                );
              })
            )}

            <div style={{ marginTop: 12 }}>
              <strong>Calm sessions:</strong> {calmStreak}
            </div>
            <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
              <button onClick={() => { setMoodLog([]); speak("Mood log cleared"); }} style={{ padding: 8, borderRadius: 8, border: "none", background: "#EF5350", color: "#fff", cursor: "pointer" }}>Clear Mood Log</button>
              <button onClick={exportMoodLog} style={{ padding: 8, borderRadius: 8, border: "none", background: "#9CCC65", color: "#fff", cursor: "pointer" }}>Export Mood Log</button>
            </div>
          </section>
        )}

        {/* Mood Journal */}
        {showJournal && (
          <section style={sectionStyle(colors.card)}>
            <h2>📔 Mood Journal</h2>
            <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
              <select value={journalMood} onChange={(e) => setJournalMood(e.target.value)} style={{ padding: 8, borderRadius: 8 }}>
                <option value="calm">calm</option>
                <option value="happy">happy</option>
                <option value="sad">sad</option>
                <option value="angry">angry</option>
                <option value="scared">scared</option>
                <option value="tired">tired</option>
                <option value="excited">excited</option>
                <option value="confused">confused</option>
                <option value="bored">bored</option>
                <option value="relaxed">relaxed</option>
                <option value="frustrated">frustrated</option>
              </select>

              <input type="date" value={journalDate} onChange={(e) => setJournalDate(e.target.value)} style={{ padding: 8, borderRadius: 8 }} />

              <button onClick={saveJournalEntry} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#4DB6AC", color: "#fff", cursor: "pointer" }}>Save Entry</button>

              <button onClick={exportJournal} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#9CCC65", color: "#fff", cursor: "pointer" }}>Export Journal</button>
            </div>

            <textarea placeholder="Write how you feel..." value={journalText} onChange={(e) => setJournalText(e.target.value)} rows={6} style={{ width: "100%", marginTop: 12, padding: 12, borderRadius: 8, border: "1px solid #ddd" }} />

            <div style={{ marginTop: 12 }}>
              <h4>Recent entries</h4>
              {journalEntries.length === 0 ? <p>No journal entries yet.</p> : (
                <div style={{ display: "grid", gap: 8 }}>
                  {journalEntries.slice().reverse().map((je) => (
                    <div key={je.id} style={{ borderRadius: 8, padding: 10, background: "#fafafa", display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
                      <div>
                        <div style={{ fontSize: 13, color: "#666" }}>{je.date} • {je.time} • <strong>{je.mood}</strong></div>
                        <div style={{ marginTop: 6 }}>{je.text}</div>
                      </div>
                      <div style={{ display: "flex", gap: 8 }}>
                        <button onClick={() => { speak(je.text); }} style={{ padding: 6, borderRadius: 6, border: "none", background: "#4DB6AC", color: "#fff", cursor: "pointer" }}>🔊</button>
                        <button onClick={() => deleteJournalEntry(je.id)} style={{ padding: 6, borderRadius: 6, border: "none", background: "#EF5350", color: "#fff", cursor: "pointer" }}>🗑️</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        <footer style={{ textAlign: "center", marginTop: 20 }}>
          🗣️ Spoken {spokenCount} times today • Keep expressing yourself 💙
        </footer>
      </main>

      {/* Popup suggestions */}
      {showPopup && (
        <div style={popupOverlay} role="dialog" aria-modal="true" aria-label="Suggestions">
          <div style={popupBox}>
            <h3 style={{ marginTop: 0 }}>💡 Suggestions to help</h3>
            <ul style={{ textAlign: "left", paddingLeft: 18 }}>
              {popupSuggestions.map((s, i) => <li key={i} style={{ marginBottom: 8 }}>{s}</li>)}
            </ul>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 12 }}>
              <button onClick={() => { popupSuggestions.forEach((p, i) => setTimeout(() => speak(p, 0.9), i * 2000)); }} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#4DB6AC", color: "#fff", cursor: "pointer" }}>🔊 Speak Suggestions</button>
              <button onClick={() => setShowPopup(false)} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#90A4AE", color: "#fff", cursor: "pointer" }}>Close</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes breathe {
          0%,100%{ transform: scale(1); opacity: 0.95; }
          50%{ transform: scale(1.35); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
