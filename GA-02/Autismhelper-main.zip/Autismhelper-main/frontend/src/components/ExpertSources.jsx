// ExpertDirectoryFull.jsx
import React, { useEffect, useState } from "react";

export default function ExpertDirectoryFull() {
  // Daily quotes (spoken on load if voiceAuto is true)
  const quotes = [
    "Different, not less. — Temple Grandin",
    "Every small step forward counts.",
    "Support and patience grow understanding.",
    "You are capable of amazing things.",
    "Autism: many strengths, many ways to be smart."
  ];

  // Expert categories
  const experts = [
    {
      icon: "🩺",
      title: "Doctors & Pediatricians",
      short: "Medical professionals for growth, diagnosis and follow-up.",
      more:
        "Doctors and pediatricians track developmental milestones, advise on medical issues and refer to specialists when needed. They coordinate with therapists for holistic care.",
      related: ["Psychologists", "Therapists"],
    },
    {
      icon: "🧠",
      title: "Psychologists",
      short: "Behavioral & emotional support specialists.",
      more:
        "Psychologists conduct assessments, design behavior plans, and provide therapies like CBT and play therapy to help emotional regulation and social skills.",
      related: ["Therapists", "Educators"],
    },
    {
      icon: "💬",
      title: "Speech & Occupational Therapists",
      short: "Communication and daily-living skills specialists.",
      more:
        "Speech therapists support language and social communication. Occupational therapists support sensory needs, fine motor skills and independence in daily life.",
      related: ["Doctors & Pediatricians", "Educators"],
    },
    {
      icon: "🎓",
      title: "Educators & Special Schools",
      short: "Trained teachers, IEPs and structured classrooms.",
      more:
        "Special educators design Individualized Education Plans (IEPs), use visual and multi-sensory methods and create predictable routines that help learning.",
      related: ["Therapists", "Organizations"],
    },
    {
      icon: "🌍",
      title: "Organizations & Support Groups",
      short: "Networks, helplines and advocacy organizations.",
      more:
        "Organizations provide resources, community support, advocacy, and training for caregivers and professionals.",
      related: ["Community & Caregivers", "Research"],
    },
  ];

  // Realistic example doctor list (replace numbers/details as needed)
  const doctors = [
    {
      id: 1,
      name: "Dr. Nandini Sharma",
      specialty: "Pediatric Neurologist",
      hospital: "AIIMS, New Delhi",
      city: "New Delhi",
      contact: "+91-00-000-0000",
      notes: "Clinic: Mon/Wed 10:00–13:00. Appointments recommended."
    },
    {
      id: 2,
      name: "Dr. Suresh Rao",
      specialty: "Child Psychiatrist",
      hospital: "NIMHANS, Bengaluru",
      city: "Bengaluru",
      contact: "+91-00-000-000",
      notes: "Behavioral consultations and community program referrals."
    },
    {
      id: 3,
      name: "Dr. Kavita Menon",
      specialty: "Developmental Pediatrician",
      hospital: "Apollo Hospitals, Chennai",
      city: "Chennai",
      contact: "+91-0000000000",
      notes: "Focus on early intervention and therapy coordination."
    },
    {
      id: 4,
      name: "Dr. Ritu Verma",
      specialty: "Speech & Language Therapist",
      hospital: "Ummeed Child Development, Mumbai",
      city: "Mumbai",
      contact: "+91-000000000000",
      notes: "AAC, speech planning and parent training available."
    },
    {
      id: 5,
      name: "Dr. Anil Kapoor",
      specialty: "Occupational Therapist",
      hospital: "Fortis Hospital, Gurgaon",
      city: "Gurgaon",
      contact: "+91-0000000000",
      notes: "Sensory integration and functional skills coaching."
    },
  ];

  // Autism info sections
  const autismInfo = [
    {
      title: "What is Autism?",
      text:
        "Autism, or autism spectrum disorder (ASD), is a lifelong neurological difference that affects social communication, behaviours, sensory processing, and learning styles. People on the spectrum have varied strengths and needs."
    },
    {
      title: "Early Signs to Watch For",
      text:
        "Delayed speech, limited eye contact, repetitive movements, strong sensory reactions, difficulty with back-and-forth play, and difficulty understanding others' emotions may be early signs. Early evaluation helps access support sooner."
    },
    {
      title: "Common Strengths",
      text:
        "Attention to detail, strong memory for facts, intense focus in interests, creative problem solving, and honest directness are common strengths found in autistic individuals."
    },
    {
      title: "Support Strategies",
      text:
        "Use visual schedules, predictable routines, clear short instructions, sensory breaks, positive reinforcement, and collaborative therapy plans (speech, OT, behavior therapy). Respect communication preferences and sensory needs."
    },
  ];

  // helpline data
  const helplines = [
    { label: "Childline India", number: "1098" },
    { label: "National Emergency", number: "112" },
    { label: "NIMHANS Mental Health Helpline", number: "080-46110007" },
  ];

  // state
  const [tab, setTab] = useState("experts"); // experts | doctors | info
  const [search, setSearch] = useState("");
  const [cityFilter, setCityFilter] = useState("all");
  const [selectedExpert, setSelectedExpert] = useState(null);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const [favorites, setFavorites] = useState(() => JSON.parse(localStorage.getItem("expertFavs") || "[]"));
  const [voiceAuto, setVoiceAuto] = useState(() => JSON.parse(localStorage.getItem("voiceAuto") || "true"));
  const [dailyQuote, setDailyQuote] = useState(() => quotes[Math.floor(Math.random() * quotes.length)]);
  const [showHelpline, setShowHelpline] = useState(false);
  const [expandedInfo, setExpandedInfo] = useState({}); // which info items are expanded

  // persist favorites & voiceAuto
  useEffect(() => localStorage.setItem("expertFavs", JSON.stringify(favorites)), [favorites]);
  useEffect(() => localStorage.setItem("voiceAuto", JSON.stringify(voiceAuto)), [voiceAuto]);

  // speak helper
  const speak = (text, rate = 0.95) => {
    if (!("speechSynthesis" in window)) return;
    if (!voiceAuto) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = rate;
    u.pitch = 1;
    window.speechSynthesis.speak(u);
  };

  // auto speak the daily quote once on first open
  useEffect(() => {
    // speak on mount if enabled
    if (voiceAuto && dailyQuote) {
      speak(dailyQuote, 0.9);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // filtering doctors
  const cities = ["all", ...Array.from(new Set(doctors.map((d) => d.city)))];
  const filteredDoctors = doctors.filter((d) => (cityFilter === "all" ? true : d.city === cityFilter) && (d.name.toLowerCase().includes(search.toLowerCase()) || d.hospital.toLowerCase().includes(search.toLowerCase()) || d.specialty.toLowerCase().includes(search.toLowerCase())));

  // toggles
  const toggleFavorite = (key, type = "expert") => {
    // key can be expert title or doctor id string
    if (favorites.includes(key)) setFavorites((p) => p.filter((f) => f !== key));
    else setFavorites((p) => [...p, key]);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard?.writeText(text).then(() => {
      alert("Copied to clipboard: " + text);
    }).catch(() => {
      // fallback
      const tmp = document.createElement("textarea");
      tmp.value = text;
      document.body.appendChild(tmp);
      tmp.select();
      document.execCommand("copy");
      tmp.remove();
      alert("Copied to clipboard: " + text);
    });
  };

  // UI helpers
  const cardStyle = {
    background: "linear-gradient(135deg,#fbfbff,#f0fcff)",
    borderRadius: 12,
    padding: 16,
    boxShadow: "0 6px 18px rgba(11,22,40,0.06)",
    cursor: "pointer",
  };

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", minHeight: "100vh", background: "#f7fbfc", color: "#0f172a" }}>
      {/* Header */}
      <header style={{ padding: 20, borderBottom: "1px solid #e6eef6", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ flex: 1 }}>
          <h1 style={{ margin: 0, fontSize: 20 }}>🧭 ARIA — Expert & Support Directory</h1>
          <div style={{ fontSize: 13, color: "#475569", marginTop: 6 }}>Search experts, find doctors and learn about autism — voice-friendly and calm UI.</div>
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <div style={{ textAlign: "right", fontSize: 13 }}>
            <div style={{ fontWeight: 700 }}>{dailyQuote}</div>
            <div style={{ fontSize: 12, color: "#64748b" }}>Daily message</div>
          </div>

          <button
            onClick={() => setVoiceAuto((v) => !v)}
            style={{ padding: "8px 10px", borderRadius: 10, background: voiceAuto ? "#16a34a" : "#94a3b8", color: "#fff", border: "none", cursor: "pointer" }}
            title="Toggle voice auto-read"
          >
            {voiceAuto ? "🎤 Voice ON" : "🔇 Voice OFF"}
          </button>

          <button
            onClick={() => setShowHelpline(true)}
            style={{ padding: "8px 10px", borderRadius: 10, background: "#ef4444", color: "#fff", border: "none", cursor: "pointer" }}
            title="Open helpline"
          >
            🚨 Helpline
          </button>
        </div>
      </header>

      {/* Tabs */}
      <nav style={{ display: "flex", gap: 8, padding: 16, alignItems: "center" }}>
        <button onClick={() => setTab("experts")} style={{ padding: "8px 12px", borderRadius: 10, background: tab === "experts" ? "#3b82f6" : "#eef2ff", color: tab === "experts" ? "#fff" : "#1e293b", border: "none", cursor: "pointer" }}>Experts</button>
        <button onClick={() => setTab("doctors")} style={{ padding: "8px 12px", borderRadius: 10, background: tab === "doctors" ? "#3b82f6" : "#eef2ff", color: tab === "doctors" ? "#fff" : "#1e293b", border: "none", cursor: "pointer" }}>Doctors</button>
        <button onClick={() => setTab("info")} style={{ padding: "8px 12px", borderRadius: 10, background: tab === "info" ? "#3b82f6" : "#eef2ff", color: tab === "info" ? "#fff" : "#1e293b", border: "none", cursor: "pointer" }}>Autism Info</button>

        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <input placeholder="Search name / hospital / specialty" value={search} onChange={(e) => setSearch(e.target.value)} style={{ padding: "8px 10px", borderRadius: 10, border: "1px solid #e6eef6", minWidth: 240 }} />
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => { setFavorites([]); localStorage.removeItem("expertFavs"); }} title="Clear saved favorites" style={{ background: "#94a3b8", color: "#fff", border: "none", padding: "8px 10px", borderRadius: 10, cursor: "pointer" }}>Clear Favorites</button>
          </div>
        </div>
      </nav>

      <main style={{ padding: 20, display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
        {/* Left column */}
        <section>
          {/* Experts Tab */}
          {tab === "experts" && (
            <div>
              <h3 style={{ marginTop: 0 }}>Expert Categories</h3>
              <div style={{ display: "grid", gap: 12 }}>
                {experts.map((ex) => (
                  <div key={ex.title} style={cardStyle} onClick={() => { setSelectedExpert(ex); speak(ex.more); }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div>
                        <div style={{ fontSize: 18, fontWeight: 700 }}>{ex.icon} {ex.title}</div>
                        <div style={{ color: "#475569", marginTop: 6 }}>{ex.short}</div>
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                        <button onClick={(e) => { e.stopPropagation(); toggleFavorite(ex.title); }} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: favorites.includes(ex.title) ? "#ef4444" : "#3b82f6", color: "#fff", cursor: "pointer" }}>{favorites.includes(ex.title) ? "❤️ Saved" : "🤍 Save"}</button>
                        <button onClick={(e) => { e.stopPropagation(); speak(ex.more); }} style={{ padding: "6px 8px", borderRadius: 8, border: "1px solid #e6eef6", background: "#fff", cursor: "pointer" }}>🔊 Read</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Doctors Tab */}
          {tab === "doctors" && (
            <div>
              <h3 style={{ marginTop: 0 }}>Doctors & Hospitals</h3>

              <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                <label style={{ alignItems: "center", display: "flex", gap: 8 }}>
                  <strong>City:</strong>
                  <select value={cityFilter} onChange={(e) => setCityFilter(e.target.value)} style={{ padding: 8, borderRadius: 8, border: "1px solid #e6eef6" }}>
                    {cities.map((c) => (<option key={c} value={c}>{c}</option>))}
                  </select>
                </label>
              </div>

              <div style={{ display: "grid", gap: 12 }}>
                {filteredDoctors.map((doc) => (
                  <div key={doc.id} style={{ ...cardStyle, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div onClick={() => { setSelectedDoctor(doc); speak(`${doc.name}, ${doc.specialty} at ${doc.hospital}. ${doc.notes}`); }} style={{ flex: 1, cursor: "pointer" }}>
                      <div style={{ fontWeight: 700 }}>{doc.name}</div>
                      <div style={{ color: "#475569", fontSize: 13 }}>{doc.specialty} — {doc.hospital} • {doc.city}</div>
                      <div style={{ color: "#64748b", fontSize: 13, marginTop: 6 }}>{doc.notes}</div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8, marginLeft: 12 }}>
                      <button onClick={() => { toggleFavorite(String(doc.id)); }} style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: favorites.includes(String(doc.id)) ? "#ef4444" : "#3b82f6", color: "#fff", cursor: "pointer" }}>
                        {favorites.includes(String(doc.id)) ? "❤️ Saved" : "🤍 Save"}
                      </button>
                      <a href={`tel:${doc.contact.replace(/\s+/g, "")}`} style={{ padding: "8px 12px", borderRadius: 8, textDecoration: "none", textAlign: "center", background: "#10b981", color: "#fff", cursor: "pointer" }}>📞 Call</a>
                    </div>
                  </div>
                ))}
                {filteredDoctors.length === 0 && <div style={{ color: "#64748b" }}>No doctors found for your filters.</div>}
              </div>
            </div>
          )}

          {/* Autism Info Tab */}
          {tab === "info" && (
            <div>
              <h3 style={{ marginTop: 0 }}>About Autism — Quick Guide</h3>
              <div style={{ display: "grid", gap: 12 }}>
                {autismInfo.map((info, idx) => (
                  <article key={idx} style={{ ...cardStyle }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                      <div>
                        <h4 style={{ margin: "4px 0 8px 0" }}>{info.title}</h4>
                        {expandedInfo[idx] ? <p style={{ color: "#334155", lineHeight: 1.5 }}>{info.text}</p> : <p style={{ color: "#64748b" }}>{info.text.slice(0, 140)}{info.text.length > 140 ? "…" : ""}</p>}
                      </div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                        <button onClick={() => { speak(info.text); }} style={{ padding: "8px 10px", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff", cursor: "pointer" }}>🔊 Read</button>
                        <button onClick={() => setExpandedInfo((p) => ({ ...p, [idx]: !p[idx] }))} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #e6eef6", background: "#fff", cursor: "pointer" }}>{expandedInfo[idx] ? "Collapse" : "Read more"}</button>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          )}
        </section>

        {/* Right column: sidebar with favorites, selected details */}
        <aside style={{ position: "sticky", top: 20 }}>
          {/* Favorites */}
          <div style={{ ...cardStyle }}>
            <h4 style={{ marginTop: 0 }}>⭐ Favorites</h4>
            <div style={{ minHeight: 60 }}>
              {favorites.length === 0 && <div style={{ color: "#64748b" }}>No favorites saved yet.</div>}
              {favorites.map((f) => {
                // try to resolve whether favorite is expert title or doctor id
                const doc = doctors.find((d) => String(d.id) === String(f));
                return (
                  <div key={f} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, marginBottom: 8 }}>
                    <div style={{ fontSize: 14 }}>
                      {doc ? (<div><strong>{doc.name}</strong><div style={{ fontSize: 12, color: "#64748b" }}>{doc.hospital}</div></div>) : (<div style={{ fontSize: 14 }}>{f}</div>)}
                    </div>
                    <div style={{ display: "flex", gap: 6 }}>
                      {doc && <button onClick={() => { speak(`${doc.name}, ${doc.specialty} at ${doc.hospital}`); }} style={{ padding: "6px 8px", background: "#3b82f6", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer" }}>🔊</button>}
                      <button onClick={() => toggleFavorite(f)} style={{ padding: "6px 8px", background: "#ef4444", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer" }}>Remove</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected expert / doctor preview */}
          <div style={{ ...cardStyle, marginTop: 12 }}>
            <h4 style={{ marginTop: 0 }}>Preview</h4>
            {selectedExpert ? (
              <div>
                <div style={{ fontWeight: 700 }}>{selectedExpert.title}</div>
                <div style={{ color: "#64748b", marginTop: 6 }}>{selectedExpert.more}</div>
                <div style={{ marginTop: 8 }}>
                  <strong>Related:</strong> {selectedExpert.related.join(", ")}
                </div>
                <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                  <button onClick={() => speak(selectedExpert.more)} style={{ padding: "8px 10px", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff" }}>🔊 Read</button>
                  <button onClick={() => setSelectedExpert(null)} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #e6eef6" }}>Close</button>
                </div>
              </div>
            ) : selectedDoctor ? (
              <div>
                <div style={{ fontWeight: 700 }}>{selectedDoctor.name}</div>
                <div style={{ color: "#64748b", marginTop: 6 }}>{selectedDoctor.specialty} • {selectedDoctor.hospital}</div>
                <div style={{ marginTop: 8 }}>
                  <strong>Contact:</strong> <a href={`tel:${selectedDoctor.contact}`} style={{ color: "#0ea5e9", textDecoration: "none" }}>{selectedDoctor.contact}</a>
                </div>
                <div style={{ marginTop: 8 }}>{selectedDoctor.notes}</div>
                <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                  <button onClick={() => { speak(`${selectedDoctor.name}, ${selectedDoctor.specialty} at ${selectedDoctor.hospital}. ${selectedDoctor.notes}`); }} style={{ padding: "8px 10px", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff" }}>🔊 Read</button>
                  <button onClick={() => { copyToClipboard(selectedDoctor.contact); }} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #e6eef6" }}>📋 Copy</button>
                  <a href={`tel:${selectedDoctor.contact.replace(/\s+/g, "")}`} style={{ padding: "8px 10px", borderRadius: 8, background: "#10b981", color: "#fff", textDecoration: "none" }}>📞 Call</a>
                </div>
              </div>
            ) : (
              <div style={{ color: "#64748b" }}>Select an expert or doctor to preview details here.</div>
            )}
          </div>

          {/* Quick actions */}
          <div style={{ ...cardStyle, marginTop: 12 }}>
            <h4 style={{ marginTop: 0 }}>Quick Actions</h4>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <button onClick={() => { setTab("doctors"); setSearch(""); setCityFilter("all"); }} style={{ padding: "8px 10px", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff" }}>Search Doctors</button>
              <button onClick={() => { setTab("info"); speak("Open autism information for helpful strategies and signs."); }} style={{ padding: "8px 10px", borderRadius: 8, border: "1px solid #e6eef6" }}>Learn about Autism</button>
              <button onClick={() => setShowHelpline(true)} style={{ padding: "8px 10px", borderRadius: 8, border: "none", background: "#ef4444", color: "#fff" }}>Helpline</button>
            </div>
          </div>
        </aside>
      </main>

      {/* Helpline modal (floating) */}
      {showHelpline && (
        <div onClick={() => setShowHelpline(false)} style={{ position: "fixed", inset: 0, background: "rgba(2,6,23,0.55)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 900 }}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", padding: 20, borderRadius: 12, width: 340, textAlign: "center", boxShadow: "0 10px 30px rgba(2,6,23,0.25)" }}>
            <h3 style={{ marginTop: 0 }}>🚨 Emergency & Support Lines</h3>
            {helplines.map(h => (
              <div key={h.number} style={{ margin: "8px 0" }}>
                <div style={{ fontWeight: 700 }}>{h.label}</div>
                <div style={{ color: "#0ea5e9", marginTop: 4 }}>
                  <a href={`tel:${h.number.replace(/\s+/g, "")}`} style={{ color: "#0ea5e9", textDecoration: "none" }}>{h.number}</a>
                </div>
              </div>
            ))}
            <div style={{ marginTop: 12 }}>
              <button onClick={() => { setShowHelpline(false); }} style={{ padding: "8px 14px", borderRadius: 8, border: "none", background: "#3b82f6", color: "#fff" }}>Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Floating helpline quick button bottom-right */}
      <button onClick={() => setShowHelpline(true)} style={{ position: "fixed", right: 18, bottom: 18, padding: 14, borderRadius: 999, background: "#ef4444", color: "#fff", border: "none", boxShadow: "0 8px 24px rgba(239,68,68,0.3)", cursor: "pointer" }} aria-label="Open helpline">
        🚨 Helpline
      </button>

      <footer style={{ textAlign: "center", padding: 18, color: "#64748b", borderTop: "1px solid #e6eef6", marginTop: 20 }}>
        © {new Date().getFullYear()} ARIA — Autism Support Hub. Data examples are for demonstration; replace with verified local contacts as needed.
      </footer>
    </div>
  );
}
