import React, { useState, useEffect } from "react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";

export default function LearningMode() {
  const [lessons, setLessons] = useState({});
  const [selectedCategory, setSelectedCategory] = useState("communication");
  const [selectedLesson, setSelectedLesson] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [mode, setMode] = useState("calm");
  const [selectedOption, setSelectedOption] = useState(null);
  const [score, setScore] = useState(0);

  const categories = [
    { id: "communication", name: "Talk & Share", icon: "💬", color: "#0ea5e9" },
    { id: "social", name: "Make Friends", icon: "🤝", color: "#22c55e" },
    { id: "daily", name: "Daily Life", icon: "🏠", color: "#f59e0b" },
    { id: "emotions", name: "Feelings & Calm", icon: "🧘‍♀️", color: "#a855f7" },
    { id: "safety", name: "Safety Rules", icon: "🚦", color: "#ef4444" },
    { id: "school", name: "School Skills", icon: "🎒", color: "#06b6d4" },
    { id: "community", name: "Community", icon: "🏘️", color: "#84cc16" },
  ];

  // --- Difficulty colors for lesson borders ---
  const difficultyColors = {
    beginner: "#22c55e",
    intermediate: "#facc15",
    advanced: "#ec4899",
  };

  // === SPEECH ===
  const speak = (text) => {
    const synth = window.speechSynthesis;
    if (!synth) return;
    const u = new SpeechSynthesisUtterance(text);
    u.rate = mode === "calm" ? 0.85 : 1.2;
    u.pitch = mode === "calm" ? 0.9 : 1.1;
    synth.cancel();
    synth.speak(u);
  };

  // === LESSON DATA ===
  const allLessons = {
    // COMMUNICATION
    comm_001: {
      title: "Basic Greetings",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Smile and say 'Hello!' when you meet someone new.",
          question: "How can you greet someone?",
          options: ["Ignore them", "Say Hello!", "Run away", "Yell loudly"],
          correct: 1,
        },
        {
          instruction: "Wave your hand gently to greet someone without words.",
          question: "How do you greet silently?",
          options: ["Wave", "Jump", "Hide", "Turn away"],
          correct: 0,
        },
      ],
    },
    comm_002: {
      title: "Expressing Needs",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Say 'I want water' when you feel thirsty.",
          question: "What do you say when you are thirsty?",
          options: [
            "I want water",
            "I am sleepy",
            "No words",
            "I am sad",
          ],
          correct: 0,
        },
        {
          instruction: "Say 'I need help' when something is hard to do.",
          question: "What can you say when you need help?",
          options: ["I need help", "Go away", "Nothing", "Cry"],
          correct: 0,
        },
      ],
    },
    // SOCIAL
    social_001: {
      title: "Making Friends",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Say 'Can I play with you?' to join others.",
          question: "How do you ask to play?",
          options: [
            "Can I play with you?",
            "Give me that!",
            "Go away!",
            "Say nothing",
          ],
          correct: 0,
        },
        {
          instruction: "Smile when your friend says yes.",
          question: "What should you do when someone says yes?",
          options: ["Smile", "Frown", "Leave", "Yell"],
          correct: 0,
        },
      ],
    },
    social_002: {
      title: "Sharing",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Offer your toy and say 'Do you want to play together?'",
          question: "What can you say when sharing?",
          options: [
            "Do you want to play together?",
            "This is mine!",
            "No!",
            "Nothing",
          ],
          correct: 0,
        },
        {
          instruction: "Say 'Thank you' when someone shares with you.",
          question: "What do you say when someone shares?",
          options: ["No!", "Thank you!", "Mine!", "Ignore them"],
          correct: 1,
        },
      ],
    },
    // DAILY LIFE
    daily_001: {
      title: "Morning Routine",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Start your day by brushing your teeth.",
          question: "What should you do first?",
          options: ["Brush teeth", "Eat candy", "Sleep", "Play"],
          correct: 0,
        },
        {
          instruction: "After brushing, wash your face and eat breakfast.",
          question: "What comes after brushing?",
          options: [
            "Wash face",
            "Go to bed",
            "Play games",
            "Watch TV",
          ],
          correct: 0,
        },
      ],
    },
    daily_002: {
      title: "Bedtime Routine",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Change into pajamas before bed.",
          question: "What clothes do you wear to sleep?",
          options: [
            "Pajamas",
            "School uniform",
            "Party dress",
            "Jeans",
          ],
          correct: 0,
        },
        {
          instruction: "Brush your teeth and read a short story.",
          question: "What should you do before sleeping?",
          options: [
            "Brush teeth",
            "Play games",
            "Eat snacks",
            "Go outside",
          ],
          correct: 0,
        },
      ],
    },
    // EMOTIONS
    emo_001: {
      title: "Recognizing Emotions",
      difficulty: "beginner",
      steps: [
        {
          instruction: "A smile means happy, tears mean sad.",
          question: "What does a smile mean?",
          options: ["Sad", "Happy", "Angry", "Scared"],
          correct: 1,
        },
        {
          instruction: "Ask 'Are you okay?' if a friend looks sad.",
          question: "What can you say to a sad friend?",
          options: [
            "Are you okay?",
            "Be quiet!",
            "Laugh",
            "Walk away",
          ],
          correct: 0,
        },
      ],
    },
    emo_002: {
      title: "Staying Calm",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Take deep breaths when you feel angry.",
          question: "What helps when you feel upset?",
          options: ["Deep breaths", "Yelling", "Crying", "Running away"],
          correct: 0,
        },
        {
          instruction: "Count from 1 to 5 slowly to calm down.",
          question: "What can you do to relax?",
          options: [
            "Count 1 to 5",
            "Jump around",
            "Hit things",
            "Cry loudly",
          ],
          correct: 0,
        },
      ],
    },
    // SAFETY
    safety_001: {
      title: "Road Safety",
      difficulty: "intermediate",
      steps: [
        {
          instruction: "Hold an adult's hand near roads.",
          question: "What should you do near traffic?",
          options: [
            "Hold an adult's hand",
            "Run fast",
            "Close eyes",
            "Ignore cars",
          ],
          correct: 0,
        },
        {
          instruction: "Look left and right before crossing.",
          question: "How do you cross safely?",
          options: [
            "Look both ways",
            "Run fast",
            "Close eyes",
            "Dance",
          ],
          correct: 0,
        },
      ],
    },
    safety_002: {
      title: "Home Safety",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Do not touch electrical sockets.",
          question: "What should you avoid touching?",
          options: [
            "Sockets",
            "Books",
            "Toys",
            "Tables",
          ],
          correct: 0,
        },
        {
          instruction: "Ask for help if something breaks.",
          question: "What do you do if something breaks?",
          options: [
            "Ask an adult for help",
            "Hide it",
            "Touch it",
            "Ignore it",
          ],
          correct: 0,
        },
      ],
    },
    // SCHOOL
    school_001: {
      title: "Listening in Class",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Look at your teacher while they speak.",
          question: "How do you show you're listening?",
          options: [
            "Look at the teacher",
            "Talk to friends",
            "Play games",
            "Look down",
          ],
          correct: 0,
        },
        {
          instruction: "Raise your hand before speaking.",
          question: "What should you do before talking?",
          options: [
            "Raise your hand",
            "Shout",
            "Interrupt",
            "Stay silent",
          ],
          correct: 0,
        },
      ],
    },
    // COMMUNITY
    community_001: {
      title: "Helping Others",
      difficulty: "beginner",
      steps: [
        {
          instruction: "Hold the door for someone behind you.",
          question: "How can you help others?",
          options: [
            "Hold the door",
            "Walk away",
            "Close it fast",
            "Ignore",
          ],
          correct: 0,
        },
        {
          instruction: "Say 'Can I help you?' when someone looks confused.",
          question: "What can you say to offer help?",
          options: [
            "Can I help you?",
            "Move away!",
            "Do it yourself",
            "Nothing",
          ],
          correct: 0,
        },
      ],
    },
  };

  // === Assign lessons to categories ===
  useEffect(() => {
    setLessons({
      communication: [
        { id: "comm_001", title: "Basic Greetings", difficulty: "beginner" },
        { id: "comm_002", title: "Expressing Needs", difficulty: "beginner" },
      ],
      social: [
        { id: "social_001", title: "Making Friends", difficulty: "beginner" },
        { id: "social_002", title: "Sharing", difficulty: "beginner" },
      ],
      daily: [
        { id: "daily_001", title: "Morning Routine", difficulty: "beginner" },
        { id: "daily_002", title: "Bedtime Routine", difficulty: "beginner" },
      ],
      emotions: [
        { id: "emo_001", title: "Recognizing Emotions", difficulty: "beginner" },
        { id: "emo_002", title: "Staying Calm", difficulty: "beginner" },
      ],
      safety: [
        { id: "safety_001", title: "Road Safety", difficulty: "intermediate" },
        { id: "safety_002", title: "Home Safety", difficulty: "beginner" },
      ],
      school: [
        { id: "school_001", title: "Listening in Class", difficulty: "beginner" },
      ],
      community: [
        { id: "community_001", title: "Helping Others", difficulty: "beginner" },
      ],
    });
  }, []);

  // === Lesson logic ===
  const startLesson = (lesson) => {
    setSelectedLesson(lesson);
    setCurrentStep(0);
    setSelectedOption(null);
    setScore(0);
    speak(allLessons[lesson.id].steps[0].instruction);
  };

  const nextStep = () => {
    const content = allLessons[selectedLesson.id];
    if (currentStep < content.steps.length - 1) {
      setCurrentStep(currentStep + 1);
      setSelectedOption(null);
      speak(content.steps[currentStep + 1].instruction);
    } else {
      alert(`🎉 Well done! Score: ${score}/${content.steps.length}`);
      setSelectedLesson(null);
    }
  };

  const handleAnswerSelect = (idx) => {
    setSelectedOption(idx);
    const step = allLessons[selectedLesson.id].steps[currentStep];
    if (idx === step.correct) {
      setScore((prev) => prev + 1);
      speak("That’s correct! Great job!");
    } else {
      speak("Try again!");
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        padding: "2rem",
        background:
          mode === "calm"
            ? "linear-gradient(to bottom right, #ecfdf5, #f0fdfa)"
            : "linear-gradient(to bottom right, #fff7ed, #fef3c7)",
        transition: "0.4s",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Header */}
      <header style={{ textAlign: "center", marginBottom: "2rem" }}>
        <h1 style={{ fontSize: "2rem", fontWeight: 800 }}>🧩 Learning Mode</h1>
        <p style={{ color: "#64748b" }}>
          Calm, interactive lessons for communication, social, and safety skills.
        </p>
        <div style={{ marginTop: "1rem" }}>
          <Button
            onClick={() => setMode("calm")}
            style={{
              background: mode === "calm" ? "#a7f3d0" : "#e2e8f0",
              marginRight: "0.5rem",
            }}
          >
            🌙 Calm
          </Button>
          <Button
            onClick={() => setMode("play")}
            style={{
              background: mode === "play" ? "#fde68a" : "#e2e8f0",
            }}
          >
            🎨 Play
          </Button>
        </div>
      </header>

      {/* Active Lesson */}
      {selectedLesson ? (
        <Card
          style={{
            maxWidth: "650px",
            margin: "0 auto",
            borderRadius: "1rem",
            background: "#fff",
            boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          }}
        >
          <CardContent style={{ padding: "1.5rem" }}>
            <h2>{selectedLesson.title}</h2>
            <p style={{ color: "#64748b" }}>
              Step {currentStep + 1} of {allLessons[selectedLesson.id].steps.length}
            </p>
            <div
              style={{
                marginTop: "1rem",
                background: "#f8fafc",
                padding: "1rem",
                borderRadius: "0.75rem",
              }}
            >
              {allLessons[selectedLesson.id].steps[currentStep].instruction}
            </div>

            {/* Question */}
            <div style={{ marginTop: "1rem" }}>
              <strong>Q:</strong>{" "}
              {allLessons[selectedLesson.id].steps[currentStep].question}
              <ul style={{ listStyle: "none", padding: 0, marginTop: "0.75rem" }}>
                {allLessons[selectedLesson.id].steps[currentStep].options.map(
                  (opt, idx) => {
                    const correct =
                      idx ===
                      allLessons[selectedLesson.id].steps[currentStep].correct;
                    const selected = selectedOption === idx;
                    let bg = "#f1f5f9";
                    if (selected && correct) bg = "#bbf7d0";
                    else if (selected && !correct) bg = "#fecaca";

                    return (
                      <li
                        key={idx}
                        onClick={() => handleAnswerSelect(idx)}
                        style={{
                          background: bg,
                          marginBottom: "0.5rem",
                          padding: "0.6rem 1rem",
                          borderRadius: "0.5rem",
                          cursor: "pointer",
                          transition: "background 0.3s",
                        }}
                      >
                        {opt}
                      </li>
                    );
                  }
                )}
              </ul>
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginTop: "1.5rem",
              }}
            >
              <Button onClick={nextStep}>
                {currentStep ===
                allLessons[selectedLesson.id].steps.length - 1
                  ? "Finish 🎉"
                  : "Next →"}
              </Button>
              <Button variant="outline" onClick={() => setSelectedLesson(null)}>
                ❌ Exit
              </Button>
            </div>

            <p
              style={{
                textAlign: "right",
                color: "#64748b",
                marginTop: "0.75rem",
              }}
            >
              Score: {score}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <h2 style={{ textAlign: "center", fontWeight: 700, marginBottom: "1rem" }}>
            Choose a Learning Category
          </h2>
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: "1rem",
              marginBottom: "2rem",
            }}
          >
            {categories.map((cat) => (
              <Button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                style={{
                  background:
                    selectedCategory === cat.id ? cat.color : "#e2e8f0",
                  color: selectedCategory === cat.id ? "#fff" : "#000",
                  padding: "0.75rem 1rem",
                  borderRadius: "1rem",
                }}
              >
                {cat.icon} {cat.name}
              </Button>
            ))}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: "1rem",
              maxWidth: "1000px",
              margin: "0 auto",
            }}
          >
            {lessons[selectedCategory] &&
              lessons[selectedCategory].map((lesson) => (
                <Card
                  key={lesson.id}
                  style={{
                    border: `3px solid ${difficultyColors[lesson.difficulty]}`,
                    borderRadius: "1rem",
                    cursor: "pointer",
                    background: "#fff",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
                  }}
                  onClick={() => startLesson(lesson)}
                >
                  <CardContent style={{ padding: "1rem" }}>
                    <h4 style={{ fontWeight: 700 }}>{lesson.title}</h4>
                    <p style={{ color: "#64748b" }}>
                      Difficulty: {lesson.difficulty}
                    </p>
                    <Button style={{ marginTop: "0.5rem" }}>
                      🚀 Start Lesson
                    </Button>
                  </CardContent>
                </Card>
              ))}
          </div>
        </>
      )}
    </div>
  );
}
