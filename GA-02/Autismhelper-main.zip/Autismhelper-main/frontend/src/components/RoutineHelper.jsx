import React, { useState, useEffect } from "react";

export default function RoutineHelper() {
  const [routines, setRoutines] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingRoutine, setEditingRoutine] = useState(null);
  const [streak, setStreak] = useState(0);
  const [activeAlarm, setActiveAlarm] = useState(null); // 🔔 popup state

  const [newRoutine, setNewRoutine] = useState({
    title: "",
    description: "",
    time: "",
    days: "daily",
    tasks: [""],
    alarm: true,
    sound: true,
    priority: "medium",
  });

  const alarmSound = new Audio("https://www.soundjay.com/button/beep-07.wav");
  alarmSound.load();

  const priorities = [
    { value: "high", label: "High 🔥", color: "#f87171" },
    { value: "medium", label: "Medium ⚡", color: "#facc15" },
    { value: "low", label: "Low 🌱", color: "#4ade80" },
  ];

  // 🎧 Unlock sound on user interaction
  useEffect(() => {
    const unlockSound = () => {
      alarmSound.play().then(() => {
        alarmSound.pause();
        alarmSound.currentTime = 0;
      }).catch(() => {});
      document.removeEventListener("click", unlockSound);
    };
    document.addEventListener("click", unlockSound);
  }, []);

  // 📦 Load saved data
  useEffect(() => {
    const saved = localStorage.getItem("routines");
    if (saved) setRoutines(JSON.parse(saved));
    const savedStreak = localStorage.getItem("streak");
    if (savedStreak) setStreak(Number(savedStreak));
  }, []);

  useEffect(() => {
    localStorage.setItem("routines", JSON.stringify(routines));
    localStorage.setItem("streak", streak);
  }, [routines, streak]);

  // 🔔 Notification permission
  useEffect(() => {
    if (Notification.permission !== "granted") Notification.requestPermission();
  }, []);

  // 🕰️ Alarm checker
  useEffect(() => {
    const timer = setInterval(checkAlarms, 60000);
    return () => clearInterval(timer);
  }, [routines]);

  const speak = (text) => {
    const msg = new SpeechSynthesisUtterance(text);
    msg.rate = 0.9;
    msg.pitch = 1;
    msg.lang = "en-US";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(msg);
  };

  const checkAlarms = () => {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    routines.forEach((r) => {
      if (r.alarm && r.time === currentTime) {
        triggerAlarm(r);
      }
    });
  };

  // 🔔 Trigger Alarm Popup
  const triggerAlarm = (routine) => {
    if (Notification.permission === "granted") {
      new Notification("⏰ Routine Reminder", {
        body: `It’s time for: ${routine.title}`,
        icon: "https://cdn-icons-png.flaticon.com/512/786/786205.png",
      });
    }

    if (routine.sound) alarmSound.play();
    speak(`It's time for ${routine.title}. Let's do it!`);

    setActiveAlarm(routine); // show popup
  };

  // 💤 Snooze alarm
  const snoozeRoutine = (routine) => {
    const newTime = addMinutes(routine.time, 5);
    setRoutines((prev) =>
      prev.map((r) => (r.id === routine.id ? { ...r, time: newTime } : r))
    );
    setActiveAlarm(null);
    speak("Snoozed for 5 minutes.");
  };

  // ✅ Mark Done
  const markRoutineDone = (routine) => {
    setStreak((prev) => prev + 1);
    speak("Good job completing your routine!");
    alarmSound.pause();
    alarmSound.currentTime = 0;
    setActiveAlarm(null);
  };

  const addMinutes = (timeStr, mins) => {
    let [h, m] = timeStr.split(":").map(Number);
    const date = new Date();
    date.setHours(h, m);
    date.setMinutes(date.getMinutes() + mins);
    return date.toTimeString().slice(0, 5);
  };

  // 💾 Save Routine
  const saveRoutine = () => {
    if (!newRoutine.title || !newRoutine.time) {
      alert("Please enter routine name and time.");
      return;
    }

    const preparedRoutine = {
      ...newRoutine,
      id: editingRoutine ? editingRoutine.id : Date.now(),
      tasks: newRoutine.tasks.map((t, i) => ({
        id: i + Date.now(),
        task: t,
        is_completed: false,
      })),
    };

    if (editingRoutine) {
      setRoutines((prev) =>
        prev.map((r) => (r.id === editingRoutine.id ? preparedRoutine : r))
      );
      setEditingRoutine(null);
    } else {
      setRoutines([...routines, preparedRoutine]);
    }

    setNewRoutine({
      title: "",
      description: "",
      time: "",
      days: "daily",
      tasks: [""],
      alarm: true,
      sound: true,
      priority: "medium",
    });
    setShowForm(false);
  };

  const editRoutine = (routine) => {
    setEditingRoutine(routine);
    setNewRoutine({
      ...routine,
      tasks: routine.tasks.map((t) => t.task),
    });
    setShowForm(true);
  };

  const deleteRoutine = (id) => {
    if (window.confirm("Delete this routine?")) {
      setRoutines(routines.filter((r) => r.id !== id));
    }
  };

  const toggleTask = (routineId, taskId) => {
    setRoutines((prev) =>
      prev.map((r) =>
        r.id === routineId
          ? {
              ...r,
              tasks: r.tasks.map((t) =>
                t.id === taskId
                  ? { ...t, is_completed: !t.is_completed }
                  : t
              ),
            }
          : r
      )
    );
    setStreak((prev) => prev + 1);
    speak("Nice job completing a task!");
  };

  const addTaskField = () => {
    setNewRoutine({ ...newRoutine, tasks: [...newRoutine.tasks, ""] });
  };

  const getProgress = (tasks) => {
    if (!tasks.length) return 0;
    const done = tasks.filter((t) => t.is_completed).length;
    return Math.round((done / tasks.length) * 100);
  };

  const sortedRoutines = [...routines].sort((a, b) => {
    const order = { high: 1, medium: 2, low: 3 };
    return order[a.priority] - order[b.priority];
  });

  return (
    <div
      style={{
        padding: "2rem",
        maxWidth: "900px",
        margin: "0 auto",
        fontFamily: "Inter, sans-serif",
      }}
    >
      <h2 style={{ textAlign: "center" }}>📅 Smart Routine Helper</h2>
      <p style={{ textAlign: "center", color: "#64748b" }}>
        Build habits, stay organized, and get gentle reminders.
      </p>

      <div style={{ textAlign: "center", marginBottom: "1rem" }}>
        <button onClick={() => setShowForm(!showForm)}>
          {showForm ? "❌ Cancel" : "➕ New Routine"}
        </button>
      </div>

      {/* 🧾 Routine Form */}
      {showForm && (
        <div style={{ background: "#f9fafb", padding: "1rem", borderRadius: "10px" }}>
          <h3>{editingRoutine ? "✏️ Edit Routine" : "🧩 Create Routine"}</h3>
          <input
            type="text"
            placeholder="Routine Name"
            value={newRoutine.title}
            onChange={(e) => setNewRoutine({ ...newRoutine, title: e.target.value })}
            style={{ width: "100%", padding: "0.5rem", margin: "0.25rem 0" }}
          />
          <textarea
            placeholder="Description"
            value={newRoutine.description}
            onChange={(e) => setNewRoutine({ ...newRoutine, description: e.target.value })}
            style={{ width: "100%", padding: "0.5rem", margin: "0.25rem 0" }}
          />
          <input
            type="time"
            value={newRoutine.time}
            onChange={(e) => setNewRoutine({ ...newRoutine, time: e.target.value })}
            style={{ width: "100%", padding: "0.5rem", margin: "0.25rem 0" }}
          />

          <select
            value={newRoutine.priority}
            onChange={(e) => setNewRoutine({ ...newRoutine, priority: e.target.value })}
            style={{ width: "100%", padding: "0.5rem", margin: "0.25rem 0" }}
          >
            {priorities.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>

          <label>
            <input
              type="checkbox"
              checked={newRoutine.alarm}
              onChange={(e) => setNewRoutine({ ...newRoutine, alarm: e.target.checked })}
            />{" "}
            Enable Alarm
          </label>
          <br />
          <label>
            <input
              type="checkbox"
              checked={newRoutine.sound}
              onChange={(e) => setNewRoutine({ ...newRoutine, sound: e.target.checked })}
            />{" "}
            Play Sound
          </label>

          {newRoutine.tasks.map((t, i) => (
            <input
              key={i}
              type="text"
              placeholder={`Task ${i + 1}`}
              value={t}
              onChange={(e) => {
                const updated = [...newRoutine.tasks];
                updated[i] = e.target.value;
                setNewRoutine({ ...newRoutine, tasks: updated });
              }}
              style={{ width: "100%", padding: "0.5rem", margin: "0.25rem 0" }}
            />
          ))}

          <button onClick={addTaskField}>➕ Add Task</button>
          <br />
          <button onClick={saveRoutine}>
            {editingRoutine ? "💾 Update" : "✅ Save"}
          </button>
        </div>
      )}

      {/* 🧭 Routine List */}
      {sortedRoutines.length === 0 ? (
        <p style={{ textAlign: "center", color: "#94a3b8", marginTop: "1rem" }}>
          No routines yet — create one to get started!
        </p>
      ) : (
        sortedRoutines.map((r) => {
          const color = priorities.find((p) => p.value === r.priority)?.color;
          const progress = getProgress(r.tasks);
          const barColor =
            progress < 50 ? "#fca5a5" : progress < 100 ? "#facc15" : "#4ade80";

          return (
            <div
              key={r.id}
              style={{
                background: "#fff",
                marginTop: "1rem",
                borderRadius: "10px",
                padding: "1rem",
                borderLeft: `8px solid ${color}`,
                boxShadow: "0 4px 10px rgba(0,0,0,0.05)",
              }}
            >
              <h3>
                {r.title} ⏰ {r.time}
              </h3>
              <p style={{ color: "#64748b" }}>{r.description}</p>

              {/* Progress Bar */}
              <div style={{ background: "#e2e8f0", borderRadius: "6px" }}>
                <div
                  style={{
                    width: `${progress}%`,
                    background: barColor,
                    height: "10px",
                    borderRadius: "6px",
                  }}
                ></div>
              </div>
              <small>{progress}% complete</small>

              {/* Tasks */}
              <ul>
                {r.tasks.map((t) => (
                  <li
                    key={t.id}
                    onClick={() => toggleTask(r.id, t.id)}
                    style={{
                      cursor: "pointer",
                      textDecoration: t.is_completed ? "line-through" : "none",
                    }}
                  >
                    {t.is_completed ? "✅" : "⬜"} {t.task}
                  </li>
                ))}
              </ul>

              <div>
                <button onClick={() => editRoutine(r)}>✏️ Edit</button>{" "}
                <button onClick={() => deleteRoutine(r.id)}>🗑️ Delete</button>
              </div>
            </div>
          );
        })
      )}

      <div style={{ textAlign: "center", marginTop: "2rem" }}>
        <h4>🔥 Daily Streak: {streak} tasks completed!</h4>
      </div>

      {/* 🔔 Alarm Popup */}
      {activeAlarm && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.6)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "12px",
              width: "90%",
              maxWidth: "400px",
              textAlign: "center",
              boxShadow: "0 8px 20px rgba(0,0,0,0.3)",
            }}
          >
            <h2>⏰ {activeAlarm.title}</h2>
            <p>{activeAlarm.description}</p>
            <p style={{ color: "#64748b" }}>It’s time for your routine!</p>
            <div style={{ display: "flex", justifyContent: "center", gap: "1rem" }}>
              <button
                onClick={() => snoozeRoutine(activeAlarm)}
                style={{
                  background: "#facc15",
                  color: "#000",
                  padding: "10px 16px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                💤 Snooze
              </button>
              <button
                onClick={() => markRoutineDone(activeAlarm)}
                style={{
                  background: "#4ade80",
                  color: "#fff",
                  padding: "10px 16px",
                  borderRadius: "8px",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                ✅ Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
