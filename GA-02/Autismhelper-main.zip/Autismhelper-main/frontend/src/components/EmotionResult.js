import React from "react";

function EmotionResult({ result }) {
  return (
    <div className="mt-4 p-4 border rounded-lg bg-gray-100">
      <h2 className="text-lg font-semibold">Detected Emotion: {result.emotion}</h2>
      <p className="mt-2">Suggested Activity: {result.activity}</p>
    </div>
  );
}

export default EmotionResult;
