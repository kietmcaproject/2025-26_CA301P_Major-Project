export function Input({ value, onChange, placeholder, style }) {
  return (
    <input
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      style={{
        padding: "0.5rem 0.75rem",
        borderRadius: "8px",
        border: "1px solid #cbd5f5",
        outline: "none",
        ...style,
      }}
    />
  );
}
