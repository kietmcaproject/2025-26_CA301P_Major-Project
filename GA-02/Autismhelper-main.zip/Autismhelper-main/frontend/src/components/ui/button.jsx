export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  style,
}) {
  const variants = {
    primary: { background: "#0ea5e9", color: "#fff" },
    outline: {
      background: "transparent",
      border: "1px solid #0ea5e9",
      color: "#0ea5e9",
    },
    ghost: { background: "transparent", color: "#0ea5e9" },
    secondary: { background: "#e2e8f0", color: "#1e293b" },
  };

  const sizes = {
    sm: { padding: "0.4rem 0.75rem", fontSize: "0.8rem" },
    md: { padding: "0.5rem 1rem", fontSize: "0.9rem" },
  };

  return (
    <button
      onClick={onClick}
      style={{
        borderRadius: "8px",
        border: "none",
        cursor: "pointer",
        fontWeight: 600,
        ...variants[variant],
        ...sizes[size],
        ...style,
      }}
    >
      {children}
    </button>
  );
}
