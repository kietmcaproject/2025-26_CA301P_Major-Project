export function Card({ children, style }) {
  return (
    <div
      style={{
        borderRadius: "12px",
        background: "white",
        boxShadow: "0 2px 10px rgba(0,0,0,0.08)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function CardContent({ children, style }) {
  return <div style={{ padding: "1rem", ...style }}>{children}</div>;
}
