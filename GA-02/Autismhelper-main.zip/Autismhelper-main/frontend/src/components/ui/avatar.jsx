export function Avatar({ children }) {
  return (
    <div
      style={{
        height: "3rem",
        width: "3rem",
        borderRadius: "50%",
        background: "#e2e8f0",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {children}
    </div>
  );
}
