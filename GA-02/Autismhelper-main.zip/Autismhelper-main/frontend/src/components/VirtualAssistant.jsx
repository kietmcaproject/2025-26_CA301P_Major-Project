import React, { useState, useEffect, useRef } from "react";
import { v4 as uuidv4 } from "uuid";

const VirtualAssistant = () => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const messagesEndRef = useRef(null);

  // 🎵 Create audio refs for sounds
  const sendSound = useRef(null);
  const replySound = useRef(null);

  useEffect(() => {
    sendSound.current = new Audio(
      "https://cdn.pixabay.com/download/audio/2022/03/15/audio_7fb0ee79b2.mp3?filename=pop-94319.mp3"
    );
    replySound.current = new Audio(
      "https://cdn.pixabay.com/download/audio/2022/03/15/audio_7c3561916f.mp3?filename=notification-102135.mp3"
    );
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("aria_chat");
    if (saved) setMessages(JSON.parse(saved));
    else {
      setMessages([
        {
          id: uuidv4(),
          type: "ai",
          message:
            "👋 Hello! I'm ARIA, your AI assistant — here to help you with tasks, questions, or friendly guidance. What can I help you with today?",
          timestamp: new Date(),
          emotion: "friendly",
        },
      ]);
    }
  }, []);

  useEffect(() => {
    if (messages.length > 0)
      localStorage.setItem("aria_chat", JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const playSound = (type) => {
    if (!soundOn) return;
    const sound = type === "send" ? sendSound.current : replySound.current;
    sound.currentTime = 0;
    sound.play().catch(() => {});
  };

  const sendMessage = async (msg = inputMessage) => {
    if (!msg.trim()) return;
    const userMsg = {
      id: uuidv4(),
      type: "user",
      message: msg,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputMessage("");
    setIsTyping(true);
    playSound("send");

    try {
      const res = await fetch("http://localhost:5000/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: msg }),
      });
      const data = await res.json();
      const aiReply =
        data.choices?.[0]?.message?.content ||
        "I'm sorry, I'm having trouble understanding that right now.";

      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          type: "ai",
          message: aiReply,
          timestamp: new Date(),
          emotion: "thoughtful",
        },
      ]);
      playSound("reply");
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          type: "ai",
          message:
            "⚠️ I’m unable to connect to the server right now. Please check your backend connection.",
          timestamp: new Date(),
          emotion: "error",
        },
      ]);
      playSound("reply");
    } finally {
      setIsTyping(false);
    }
  };

  const clearChat = () => {
    if (window.confirm("Clear the conversation?")) {
      setMessages([]);
      localStorage.removeItem("aria_chat");
    }
  };

  return (
    <div className={`nova-container ${darkMode ? "dark" : ""}`}>
      {/* Sidebar */}
      <div className="nova-sidebar glassy">
        <div className="sidebar-header">
          <div className={`avatar ${isTyping ? "glow" : ""}`}>
            <div className="avatar-icon">✨</div>
          </div>
          <h2>ARIA AI</h2>
        </div>

        <div className="sidebar-actions">
          <button onClick={() => setDarkMode((d) => !d)}>
            {darkMode ? "☀️ Light Mode" : "🌙 Dark Mode"}
          </button>
          <button onClick={clearChat}>🗑️ Clear Chat</button>
         
        </div>

        <footer className="sidebar-footer">
          <p>💡 Always learning. Always kind.</p>
        </footer>
      </div>

      {/* Chat Area */}
      <div className="nova-main">
        <header className="chat-header">
          <h3>ARIA Assistant</h3>
          <span>
            {messages.filter((m) => m.type === "user").length} Messages Exchanged
          </span>
        </header>

        <div className="chat-messages">
          {messages.map((m) => (
            <div key={m.id} className={`message ${m.type}`}>
              <div className="bubble fade-in">{m.message}</div>
            </div>
          ))}

          {isTyping && (
            <div className="typing">
              <div className="dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
              <p>ARIA is thinking...</p>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="chat-input-container glassy">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="Type a message..."
            disabled={isTyping}
          />
          <button onClick={() => sendMessage()} disabled={!inputMessage.trim()}>
            ➤
          </button>
        </div>
      </div>

      {/* Styles */}
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .nova-container {
          display: flex;
          height: 100vh;
          background: var(--bg);
          color: var(--text);
          font-family: "Inter", sans-serif;
          transition: background 0.4s ease, color 0.4s ease;
        }

        :root {
          --bg: #eef2f9;
          --text: #1e293b;
          --accent: #2563eb;
          --bubble-user: #2563eb;
          --bubble-ai: rgba(255,255,255,0.6);
          --glass-bg: rgba(255,255,255,0.35);
          --shadow: 0 8px 24px rgba(0,0,0,0.1);
        }

        .dark {
          --bg: #0f172a;
          --text: #e2e8f0;
          --accent: #60a5fa;
          --bubble-user: #2563eb;
          --bubble-ai: rgba(255,255,255,0.08);
          --glass-bg: rgba(30,41,59,0.45);
          --shadow: 0 8px 24px rgba(0,0,0,0.5);
        }

        .glassy {
          backdrop-filter: blur(14px);
          background: var(--glass-bg);
          border: 1px solid rgba(255,255,255,0.15);
          box-shadow: var(--shadow);
        }

        .nova-sidebar {
          width: 260px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          padding: 1.5rem;
          background: linear-gradient(135deg, #3b82f6, #6366f1, #22d3ee);
          background-size: 200% 200%;
          animation: gradientShift 8s ease infinite;
          color: white;
        }

        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }

        .avatar {
          width: 70px;
          height: 70px;
          border-radius: 50%;
          background: rgba(255,255,255,0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2rem;
          position: relative;
        }

        .avatar.glow::before {
          content: "";
          position: absolute;
          inset: -6px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(255,255,255,0.6), transparent 70%);
          animation: pulseGlow 2s infinite ease-in-out;
        }

        @keyframes pulseGlow {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.15); }
        }

        .sidebar-actions {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          margin-top: 2rem;
        }

        .sidebar-actions button {
          padding: 0.75rem 1rem;
          border-radius: 10px;
          border: none;
          cursor: pointer;
          background: rgba(255,255,255,0.25);
          color: white;
          font-weight: 600;
          transition: all 0.3s ease;
        }

        .sidebar-actions button:hover {
          background: rgba(255,255,255,0.4);
          transform: scale(1.05);
        }

        .nova-main { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
        .chat-header { padding: 1.25rem 2rem; display: flex; justify-content: space-between; }

        .chat-messages {
          flex: 1;
          overflow-y: auto;
          padding: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .message { max-width: 70%; animation: riseUp 0.3s ease; }
        .message.user { align-self: flex-end; }
        .message.ai { align-self: flex-start; }

        .bubble {
          padding: 1rem 1.25rem;
          border-radius: 1rem;
          font-size: 0.95rem;
          line-height: 1.5;
          box-shadow: var(--shadow);
        }

        .message.user .bubble { background: var(--bubble-user); color: white; }
        .message.ai .bubble { background: var(--bubble-ai); color: var(--text); }

        .fade-in { animation: fadeIn 0.4s ease; }
        @keyframes fadeIn { from {opacity: 0; transform: translateY(8px);} to {opacity:1; transform:translateY(0);} }
        @keyframes riseUp { from {opacity:0; transform:translateY(12px);} to {opacity:1; transform:translateY(0);} }

        .typing { display: flex; flex-direction: column; gap: 0.4rem; color: var(--text); opacity: 0.8; }
        .dots { display: flex; gap: 0.4rem; }
        .dots span { width: 8px; height: 8px; border-radius: 50%; background: var(--text); opacity: 0.6; animation: blink 1.5s infinite ease-in-out; }
        .dots span:nth-child(2){animation-delay:0.3s;} .dots span:nth-child(3){animation-delay:0.6s;}
        @keyframes blink {0%,80%,100%{transform:scale(0.8);opacity:0.5;}40%{transform:scale(1.1);opacity:1;}}

        .chat-input-container {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem 2rem;
          border-top: 1px solid rgba(255,255,255,0.1);
        }

        .chat-input-container input {
          flex: 1;
          padding: 0.9rem 1.2rem;
          border: none;
          border-radius: 12px;
          background: var(--glass-bg);
          color: var(--text);
          font-size: 0.9rem;
          outline: none;
        }

        .chat-input-container button {
          background: var(--accent);
          border: none;
          color: white;
          border-radius: 12px;
          width: 48px;
          height: 48px;
          font-size: 1.2rem;
          cursor: pointer;
          transition: all 0.3s ease;
        }

        .chat-input-container button:hover {
          transform: scale(1.05);
          box-shadow: 0 0 10px rgba(59,130,246,0.6);
        }

        @media (max-width: 768px) {
          .nova-container { flex-direction: column; }
          .nova-sidebar { width: 100%; flex-direction: row; justify-content: space-between; align-items: center; }
          .chat-messages { padding: 1.25rem; }
        }
      `}</style>
    </div>
  );
};

export default VirtualAssistant;
