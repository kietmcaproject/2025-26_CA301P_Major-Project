import React from "react";

const EducationalResources = () => {
  return (
    <div className="resources-page" style={{ padding: "20px" }}>
      <h2 style={{ color: "#1976d2", marginBottom: "15px" }}>📖 Educational Resources</h2>
      <p style={{ fontSize: "1.1rem", marginBottom: "25px", color: "#444" }}>
        Discover comprehensive guides, articles, and tools to support autistic individuals and their
        families.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
          gap: "20px",
        }}
      >
        <div
          style={{
            background: "#f9fafb",
            padding: "15px",
            borderRadius: "10px",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
          }}
        >
          <h3 style={{ color: "#0d47a1" }}>Guides</h3>
          <p>
            Step-by-step resources for parents, educators, and caregivers on communication,
            routines, and social growth.
          </p>
        </div>

        <div
          style={{
            background: "#f9fafb",
            padding: "15px",
            borderRadius: "10px",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
          }}
        >
          <h3 style={{ color: "#0d47a1" }}>Articles</h3>
          <p>
            Explore evidence-based articles written by experts and individuals with lived
            experiences.
          </p>
        </div>

        <div
          style={{
            background: "#f9fafb",
            padding: "15px",
            borderRadius: "10px",
            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
          }}
        >
          <h3 style={{ color: "#0d47a1" }}>Tools</h3>
          <p>
            Access visual aids, activity sheets, and practical tools to make everyday challenges
            easier.
          </p>
        </div>
      </div>
    </div>
  );
};

export default EducationalResources;
