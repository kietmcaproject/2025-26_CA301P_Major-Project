import React from "react";

function SpeechRecorder({ setResult }) {
  const handleClick = async () => {
    // Mock: send fake speech text
    const response = await fetch("http://127.0.0.1:5000/speech-to-text", {
      method: "POST"
    });
    const data = await response.json();

    // Now analyze emotion
    const emotionRes = await fetch("http://127.0.0.1:5000/analyze-emotion", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: data.text })
    });
    const result = await emotionRes.json();
    setResult(result);
  };

  return (
    <button
      onClick={handleClick}
      className="bg-blue-500 text-white px-4 py-2 rounded-lg"
    >
      🎤 Speak
    </button>
  );
}

export default SpeechRecorder;
