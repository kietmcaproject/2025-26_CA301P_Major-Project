import React from "react";

const CommunityAdvocacy = () => {
  return (
    <section
      style={{
        maxWidth: "800px",
        margin: "40px auto",
        padding: "20px",
        backgroundColor: "#e8f5e9",
        borderRadius: "16px",
        boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        color: "#2e7d32",
      }}
      aria-label="Community and Advocacy"
    >
      <h2 style={{ fontSize: "2rem", marginBottom: "20px", fontWeight: "700" }}>
        🌍 Community & Advocacy
      </h2>
      <img
        src="/images/community.jpeg" // Replace with your actual image path
        alt="Group of diverse people holding hands or community gathering"
        style={{
          width: "100%",
          maxHeight: "300px",
          objectFit: "cover",
          borderRadius: "12px",
          marginBottom: "20px",
          userSelect: "none",
        }}
        loading="lazy"
      />
      <p style={{ fontSize: "1.1rem", lineHeight: "1.6" }}>
        Building a supportive community and advocating for autism acceptance are vital for creating inclusive environments. Connecting with others who share similar experiences fosters understanding, friendship, and empowerment.
      </p>
      <p style={{ fontSize: "1.1rem", lineHeight: "1.6" }}>
        Our platform encourages sharing stories, participating in events, and raising awareness to promote respect and equal opportunities for individuals on the autism spectrum. Together, we can make a difference.
      </p>
    </section>
  );
};

export default CommunityAdvocacy;
