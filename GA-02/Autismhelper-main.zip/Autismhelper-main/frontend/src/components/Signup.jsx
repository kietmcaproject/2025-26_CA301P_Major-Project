import React, { useState, useEffect } from "react";

const Signup = ({ setActiveComponent }) => {
  const [darkMode, setDarkMode] = useState(
    JSON.parse(localStorage.getItem("darkMode")) || false
  );
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    document.body.style.background = darkMode ? "#0f172a" : "#f8fafc";
    document.body.style.color = darkMode ? "#f1f5f9" : "#1e293b";
  }, [darkMode]);

  const handleSignup = (e) => {
    e.preventDefault();

    const { name, email, password } = form;
    if (!name || !email || !password) {
      setError("Please fill in all fields.");
      return;
    }

    // Get existing users
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Check if user already exists
    const existingUser = users.find((u) => u.email === email);
    if (existingUser) {
      setError("An account with this email already exists. Please login.");
      return;
    }

    // Add new user
    const newUser = { name, email, password };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    setSuccess("Account created successfully! You can now login.");
    setError("");
    setForm({ name: "", email: "", password: "" });

    // Redirect to home/login
    setTimeout(() => setActiveComponent("home"), 1500);
  };

  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
    },
    card: {
      background: darkMode ? "#1e293b" : "white",
      color: darkMode ? "white" : "black",
      padding: "25px",
      borderRadius: "10px",
      width: "90%",
      maxWidth: "360px",
      boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
      textAlign: "center",
    },
    input: {
      width: "100%",
      padding: "10px",
      margin: "8px 0",
      borderRadius: "6px",
      border: "1px solid #ccc",
      fontSize: "0.9rem",
    },
    button: {
      background: "#22c55e",
      border: "none",
      color: "white",
      borderRadius: "6px",
      padding: "10px",
      width: "100%",
      cursor: "pointer",
      marginTop: "10px",
      fontSize: "0.9rem",
    },
    toggle: {
      background: darkMode ? "#334155" : "#1565c0",
      border: "none",
      color: "white",
      borderRadius: "16px",
      padding: "5px 10px",
      cursor: "pointer",
      fontSize: "0.8rem",
      marginTop: "15px",
    },
    link: {
      marginTop: "10px",
      display: "block",
      cursor: "pointer",
      color: "#0ea5e9",
      textDecoration: "underline",
    },
    error: { color: "red", fontSize: "0.85rem" },
    success: { color: "limegreen", fontSize: "0.85rem" },
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>Create an Account</h2>

        <form onSubmit={handleSignup}>
          <input
            type="text"
            placeholder="Full Name"
            style={styles.input}
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <input
            type="email"
            placeholder="Email Address"
            style={styles.input}
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <input
            type="password"
            placeholder="Password"
            style={styles.input}
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
          <button type="submit" style={styles.button}>
            Sign Up
          </button>
        </form>

        {error && <p style={styles.error}>{error}</p>}
        {success && <p style={styles.success}>{success}</p>}

        <button style={styles.toggle} onClick={() => setDarkMode((v) => !v)}>
          {darkMode ? "☀️ Light" : "🌙 Dark"}
        </button>

        <span
          style={styles.link}
          onClick={() => setActiveComponent("home")}
        >
          ⬅ Back to Home
        </span>
      </div>
    </div>
  );
};

export default Signup;
