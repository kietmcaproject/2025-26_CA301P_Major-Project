import React, { useState, useEffect } from "react";

const Nav = ({ activeComponent, setActiveComponent }) => {
  const [darkMode, setDarkMode] = useState(
    JSON.parse(localStorage.getItem("darkMode")) || false
  );
  const [user, setUser] = useState(null);
  const [showLogin, setShowLogin] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");

  const navItems = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "assistant", label: "ARIA", icon: "🤖" },
    { id: "communication", label: "Talk", icon: "💬" },
    { id: "routine", label: "Routine", icon: "📅" },
    { id: "learning", label: "Learn", icon: "🎓" },
    { id: "social", label: "Friends", icon: "🤝" },
    { id: "expert", label: "Experts", icon: "🧠" },
  ];

  // 🧠 Load user from localStorage on mount
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) setUser(storedUser);
  }, []);

  // 🌓 Dark mode sync
  useEffect(() => {
    document.body.style.background = darkMode ? "#0f172a" : "#f8fafc";
    document.body.style.color = darkMode ? "#f1f5f9" : "#1e293b";
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  // ✅ Handle Login with validation
  const handleLogin = (e) => {
    e.preventDefault();
    const { email, password } = loginForm;

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const existingUser = users.find((u) => u.email === email);

    if (!existingUser) {
      setError("❌ No account found. Please create one first.");
      return;
    }

    if (existingUser.password !== password) {
      setError("❌ Incorrect password. Please try again.");
      return;
    }

    // ✅ Success
    setError("");
    localStorage.setItem("user", JSON.stringify(existingUser));
    setUser(existingUser);
    setShowLogin(false);
    setLoginForm({ email: "", password: "" });
  };

  // ✅ Logout
  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
  };

  const styles = {
    nav: {
      background: darkMode ? "#1e293b" : "#1976d2",
      color: "white",
      padding: "8px 14px",
      position: "sticky",
      top: 0,
      zIndex: 1000,
      boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    },
    container: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      maxWidth: "1100px",
      margin: "0 auto",
    },
    logoContainer: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      cursor: "pointer",
    },
    logoImage: {
      width: "34px",
      height: "34px",
      borderRadius: "50%",
    },
    title: {
      margin: 0,
      fontSize: "1rem",
      fontWeight: 700,
    },
    menuDesktop: {
      listStyle: "none",
      display: "flex",
      gap: "15px",
      margin: 0,
      padding: 0,
      alignItems: "center",
    },
    item: {
      cursor: "pointer",
      padding: "6px 8px",
      borderRadius: "6px",
      transition: "0.3s",
      display: "flex",
      alignItems: "center",
      gap: "4px",
      fontSize: "0.9rem",
    },
    activeItem: {
      background: darkMode ? "#334155" : "#1565c0",
    },
    toggle: {
      background: darkMode ? "#334155" : "#1565c0",
      border: "none",
      color: "white",
      borderRadius: "16px",
      padding: "5px 10px",
      cursor: "pointer",
      fontSize: "0.8rem",
    },
    loginBtn: {
      background: "#0ea5e9",
      border: "none",
      color: "white",
      borderRadius: "16px",
      padding: "5px 12px",
      cursor: "pointer",
      fontSize: "0.8rem",
    },
    signupBtn: {
      background: "#22c55e",
      border: "none",
      color: "white",
      borderRadius: "16px",
      padding: "5px 12px",
      cursor: "pointer",
      fontSize: "0.8rem",
      marginLeft: "8px",
    },
    userName: {
      fontWeight: "bold",
      marginRight: "6px",
    },
    modalBackdrop: {
      position: "fixed",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      background: "rgba(0,0,0,0.5)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      zIndex: 2000,
    },
    modal: {
      background: darkMode ? "#1e293b" : "white",
      color: darkMode ? "white" : "black",
      padding: "20px",
      borderRadius: "10px",
      width: "90%",
      maxWidth: "350px",
      textAlign: "center",
      boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
    },
    input: {
      width: "100%",
      padding: "8px",
      margin: "8px 0",
      borderRadius: "6px",
      border: "1px solid #ccc",
      fontSize: "0.9rem",
    },
    error: {
      color: "red",
      fontSize: "0.85rem",
      marginBottom: "8px",
    },
  };

  return (
    <>
      <nav style={styles.nav}>
        <div style={styles.container}>
          {/* Logo */}
          <div
            style={styles.logoContainer}
            onClick={() => setActiveComponent("home")}
          >
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNXKQxiIS_0HkKuBBUxcGQp1bB3s8vVsDERQ&s"
              alt="Logo"
              style={styles.logoImage}
            />
            <h1 style={styles.title}>AutismHelper</h1>
          </div>

          {/* Menu */}
          <ul style={styles.menuDesktop}>
            {navItems.map((item) => (
              <li
                key={item.id}
                style={{
                  ...styles.item,
                  ...(activeComponent === item.id ? styles.activeItem : {}),
                }}
                onClick={() => setActiveComponent(item.id)}
              >
                <span>{item.icon}</span>
                {item.label}
              </li>
            ))}

            {/* Dark Mode Toggle */}
            <li>
             
            </li>

            {/* ✅ Dynamic User Area */}
            <li>
              {user ? (
                <>
                  <span style={styles.userName}>👋 {user.name}</span>
                  <button style={styles.loginBtn} onClick={handleLogout}>
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <button
                    style={styles.loginBtn}
                    onClick={() => setShowLogin(true)}
                  >
                    Login
                  </button>
                  <button
                    style={styles.signupBtn}
                    onClick={() => setActiveComponent("signup")}
                  >
                    Signup
                  </button>
                </>
              )}
            </li>
          </ul>
        </div>
      </nav>

      {/* Login Modal */}
      {showLogin && (
        <div style={styles.modalBackdrop}>
          <div style={styles.modal}>
            <h3>Login</h3>
            {error && <p style={styles.error}>{error}</p>}
            <form onSubmit={handleLogin}>
              <input
                type="email"
                placeholder="Enter your email"
                required
                style={styles.input}
                value={loginForm.email}
                onChange={(e) =>
                  setLoginForm({ ...loginForm, email: e.target.value })
                }
              />
              <input
                type="password"
                placeholder="Enter your password"
                required
                style={styles.input}
                value={loginForm.password}
                onChange={(e) =>
                  setLoginForm({ ...loginForm, password: e.target.value })
                }
              />
              <button type="submit" style={styles.loginBtn}>
                Login
              </button>
            </form>
            <button
              onClick={() => setShowLogin(false)}
              style={{ ...styles.toggle, marginTop: "10px" }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Nav;
