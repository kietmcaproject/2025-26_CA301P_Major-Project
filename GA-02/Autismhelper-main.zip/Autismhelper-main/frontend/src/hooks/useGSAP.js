import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const useGSAP = (animationType = 'fadeInUp', delay = 0) => {
  const ref = useRef();
  
  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    
    const animations = {
      fadeInUp: {
        from: { opacity: 0, y: 50, rotationX: -15 },
        to: { opacity: 1, y: 0, rotationX: 0, duration: 0.8, delay, ease: "back.out(1.7)" }
      },
      slideInLeft: {
        from: { opacity: 0, x: -100 },
        to: { opacity: 1, x: 0, duration: 0.6, delay, ease: "power2.out" }
      },
      slideInRight: {
        from: { opacity: 0, x: 100 },
        to: { opacity: 1, x: 0, duration: 0.6, delay, ease: "power2.out" }
      },
      scaleIn: {
        from: { opacity: 0, scale: 0.5 },
        to: { opacity: 1, scale: 1, duration: 0.5, delay, ease: "back.out(1.7)" }
      },
      floatIn: {
        from: { opacity: 0, y: 30, rotation: -5 },
        to: { opacity: 1, y: 0, rotation: 0, duration: 1, delay, ease: "elastic.out(1, 0.3)" }
      }
    };
    
    const anim = animations[animationType];
    gsap.fromTo(element, anim.from, anim.to);
    
    return () => {
      gsap.killTweensOf(element);
    };
  }, [animationType, delay]);
  
  return ref;
};

// Stagger animation for multiple elements
export const useStaggerAnimation = (selector = '.stagger-item', delay = 0) => {
  const containerRef = useRef();
  
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    
    const items = container.querySelectorAll(selector);
    
    gsap.fromTo(items, 
      { opacity: 0, y: 30, scale: 0.9 },
      { 
        opacity: 1, 
        y: 0, 
        scale: 1,
        duration: 0.6,
        delay,
        stagger: 0.1,
        ease: "back.out(1.7)"
      }
    );
    
    return () => {
      gsap.killTweensOf(items);
    };
  }, [selector, delay]);
  
  return containerRef;
};