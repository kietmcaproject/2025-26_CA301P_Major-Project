import React, { useState } from "react";
import Nav from "./Nav";
import Home from "./components/Home";
import VirtualAssistant from "./components/VirtualAssistant";
import CommunicationAid from "./components/CommunicationAid";
import RoutineHelper from "./components/RoutineHelper";
import LearningMode from "./components/LearningMode";
import SocialGuide from "./components/SocialGuide";
import ExpertSources from "./components/ExpertSources";
import Signup from "./components/Signup"; // ✅ Signup page import

import "./styles.css";

function App() {
  const [activeComponent, setActiveComponent] = useState("home");

  const renderComponent = () => {
    switch (activeComponent) {
      case "home":
        return <Home setActiveComponent={setActiveComponent} />;
      case "assistant":
        return <VirtualAssistant />;
      case "communication":
        return <CommunicationAid />;
      case "routine":
        return <RoutineHelper />;
      case "learning":
        return <LearningMode />;
      case "social":
        return <SocialGuide />;
      case "expert":
        return <ExpertSources />;
      case "signup": // ✅ Added case for signup
        return <Signup setActiveComponent={setActiveComponent} />;
      default:
        return <Home setActiveComponent={setActiveComponent} />;
    }
  };

  return (
    <div className="app">
      {/* ✅ Pass both props so Nav can trigger signup */}
      <Nav
        activeComponent={activeComponent}
        setActiveComponent={setActiveComponent}
      />

      <main className="main-content">
        <div key={activeComponent} className="component-wrapper">
          {renderComponent()}
        </div>
      </main>
    </div>
  );
}

export default App;
