export const api = {
  chatWithAssistant: async (userMessage) => {
    try {
      const res = await fetch("http://localhost:5000/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      });
      return await res.json();
    } catch (error) {
      console.error("Backend error:", error);
      return { success: false };
    }
  },

  logEmotion: async () => {},
  createRoutine: async () => {},
};
