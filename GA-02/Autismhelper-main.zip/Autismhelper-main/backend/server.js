import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/chat", async (req, res) => {
  try {
    const { message } = req.body;

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer 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`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openai/gpt-4o-mini",
        messages: [{ role: "user", content: message }],
      }),
    });

    const data = await response.json();
    res.json(data);
  } catch (err) {
    console.error("API Error:", err);
    res.status(500).json({ error: "Something went wrong." });
  }
});

app.listen(5000, () => console.log("✅ Server running on http://localhost:5000"));
